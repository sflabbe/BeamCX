-- BeamCX v0.6.0 (generated).
-- BeamCX offline catalogue. E in MPa, Iy (major bending axis) in cm^4.
-- Source tables are recorded in README; no files or network needed on TI.
DB = {}
DB.materials = {
    {name='MANUAL',kind='manual'},
    {name='C20/25',kind='concrete',E=30000},
    {name='C25/30',kind='concrete',E=31000},
    {name='C30/37',kind='concrete',E=33000},
    {name='S235',kind='steel',E=210000},
    {name='S355',kind='steel',E=210000}
}
-- Entries: name, nominal strong-axis Iy [cm4], mass [kg/m].
-- Mass: ArcelorMittal Sections and Merchant Bars (2021), IPE / HE A tables.
-- Source URL and table pages in README. Existing Iy values are unchanged.
DB.profiles = {
    {'IPE 100',171,8.1}, {'IPE 120',317.8,10.4}, {'IPE 140',541.2,12.9},
    {'IPE 160',869.3,15.8}, {'IPE 180',1317,18.8}, {'IPE 200',1943,22.4},
    {'IPE 220',2772,26.2}, {'IPE 240',3892,30.7}, {'IPE 270',5790,36.1},
    {'IPE 300',8356,42.2}, {'HEA 100',349.2,16.7}, {'HEA 120',606.2,19.9},
    {'HEA 140',1033,24.7}, {'HEA 160',1673,30.4}, {'HEA 180',2510,35.5},
    {'HEA 200',3692,42.3}, {'HEA 220',5410,50.5}, {'HEA 240',7763,60.3},
    {'HEA 260',10455,68.2}, {'HEA 280',13670,76.4}, {'HEA 300',18260,88.3}
}
local function positive(v)
    return type(v)=='number' and v>0 and v<math.huge and v==v
end
function DB.compute(s)
    local mat=DB.materials[s.material]
    if not mat then return nil,'invalid material' end
    if mat.kind=='manual' then
        if not positive(s.manualEI) then return nil,'invalid manual EI' end
        return {EI=s.manualEI,I=nil,E=nil,label='MANUAL',kind='manual'}
    end
    local I,label,q_sw
    if mat.kind=='concrete' then
        if not positive(s.b) or not positive(s.h) then return nil,'invalid rectangle b/h' end
        -- b,h are in mm. m^4 to cm^4 conversion is 1e8.
        I=(s.b/1000)*(s.h/1000)^3/12
        label='RECT '..s.b..'x'..s.h
        -- Nominal normal-weight reinforced concrete: 25 kN/m3.
        q_sw=25*(s.b/1000)*(s.h/1000)
    else
        local shape=DB.profiles[s.profile]
        if not shape then return nil,'invalid profile' end
        I=shape[2]*1e-8
        label=shape[1]
        if positive(shape[3]) then q_sw=shape[3]*9.81/1000 end
    end
    -- E in N/mm2 (MPa) -> kN/m2: x1000; I in m4 -> EI in kN m2.
    return {E=mat.E,I=I,EI=mat.E*1000*I,label=label,kind=mat.kind,q_sw=q_sw}
end

-- BeamCX v0.4-P1C: pure Lua 5.1, static prismatic Euler-Bernoulli frames.
-- Units: m, kN, kNm; EA in kN, EI in kN*m^2. No TI API or Beam dependency.
-- Global x right, y up, rotations CCW; downward loads are NEGATIVE.
-- Local x follows i -> j; local y is local x rotated +90 degrees.
-- DOFs: [ux_i, uy_i, rz_i, ux_j, uy_j, rz_j]. End forces are NODAL:
-- [N_i, V_i, M_i, N_j, V_j, M_j], positive moments CCW (dc ADR-002).
-- Diagrams: N positive tension; M positive when local -y fibre is in tension;
-- textbook V positive on the left face, dM/ds=V and dV/ds=q.
-- nodal_to_diagram is the ONLY end-force -> diagram sign conversion:
-- M(0)=-M_i, M(L)=+M_j. w is physical local-y displacement, u local-x.
-- Member udl/dist/point act along local y, per unit MEMBER length, for any
-- orientation. Concentrated moments act CCW about z (unchanged by rotation).
-- hinge_i/j release MEMBER rotations; reconstructed rotations drive recovery.
-- Thermal kappa_T=alphaT*dT/h: total curvature w''=M/EI-kappa_T.
-- Springs act in global DOFs; reactions include their force -k*u.
-- Global/projected member loads and axial thermal expansion are outside P1C.
-- solve/assemble return nil,message on failure; at/extrema reject bad queries.
-- moment_extrema and deflection_extrema return min, s_min, max, s_max.
Frame = {}

local PIVOT_TOL = 1e-12 -- |pivot| / original row maximum, after scaled pivoting.
local CHECK_TOL = 1e-8 -- relative to largest applied force or origin moment.
local MAX_NODES = 20 -- medido en CX CAS (BXBENCH): 20 nudos 2,7 s; 40 nudos 8,8 s; 60 nudos 20,7 s

local function finite(x)
    return type(x)=='number' and x==x and math.abs(x)<math.huge
end
local function require_number(x, name)
    if not finite(x) then error('invalid '..name, 0) end
    return x
end
local function fields(t, allowed, name)
    if type(t)~='table' then error('invalid '..name, 0) end
    for k in pairs(t) do
        if not allowed[k] then error('unsupported '..name..' field: '..tostring(k), 0) end
    end
end
local function zeros(n,m)
    local a={}
    for i=1,n do
        a[i]={}
        for j=1,m do a[i][j]=0 end
    end
    return a
end
local function vector(n)
    local v={}
    for i=1,n do v[i]=0 end
    return v
end

-- Euler branch of dc_solver/fem/frame2d.py, without shear flexibility.
function Frame.local_k(L,EA,EI)
    local k=zeros(6,6)
    local a,b,c,d,e=EA/L,12*EI/L^3,6*EI/L^2,4*EI/L,2*EI/L
    k[1][1]=a; k[1][4]=-a; k[4][1]=-a; k[4][4]=a
    local v={2,3,5,6}
    local bend={{b,c,-b,c},{c,d,-c,e},{-b,-c,b,-c},{c,e,-c,d}}
    for i=1,4 do for j=1,4 do k[v[i]][v[j]]=bend[i][j] end end
    return k
end
function Frame.transformation(c,s)
    return {{c,s,0,0,0,0},{-s,c,0,0,0,0},{0,0,1,0,0,0},
            {0,0,0,c,s,0},{0,0,0,-s,c,0},{0,0,0,0,0,1}}
end
local function rotate_k(k,T)
    local temp,kg=zeros(6,6),zeros(6,6)
    for i=1,6 do for j=1,6 do
        for a=1,6 do temp[i][j]=temp[i][j]+k[i][a]*T[a][j] end
    end end
    for i=1,6 do for j=1,6 do
        for a=1,6 do kg[i][j]=kg[i][j]+T[a][i]*temp[a][j] end
    end end
    return kg
end
local dof_names={'ux','uy','rz'}
local function dof_label(d)
    return 'node '..math.floor((d-1)/3+1)..' '..dof_names[(d-1)%3+1]
end
local function node_index(n,nn)
    if not finite(n) or n%1~=0 or n<1 or n>nn then error('invalid node index',0) end
    return n
end

-- Stable factored Hermite shapes, and derivatives with respect to s.
-- Work-conjugate pairs are (local uy, CCW rz); hence a concentrated
-- moment contributes +M*H'(a), while a transverse force contributes P*H(a).
local function hermite(L,s)
    local t=s/L
    local r=1-t
    return {r*r*(1+2*t),L*t*r*r,t*t*(3-2*t),-L*t*t*r},
           {-6*t*r/L,r*(1-3*t),6*t*r/L,t*(3*t-2)}
end
-- Retain low-order terms when loads nearly cancel an end shear. This is
-- essential for a point a few nanometres from an end: the remaining diagram
-- may be tiny compared to the support reaction, even without a short element.
local function compensated_add(sum,correction,value)
    local next_sum=sum+value
    local lost
    if math.abs(sum)>=math.abs(value) then lost=(sum-next_sum)+value
    else lost=(value-next_sum)+sum end
    return next_sum,correction+lost
end
local function add_component(fe,i,value)
    fe.correction=fe.correction or vector(6)
    fe[i],fe.correction[i]=compensated_add(fe[i],fe.correction[i],value)
end
local function add_transverse(fe,shape,factor)
    local map={2,3,5,6}
    for k=1,4 do add_component(fe,map[k],factor*shape[k]) end
end
local function add_line_load(fe,L,a,b,qa,qb)
    if a==0 and b==L then
        -- Integral H(s)^T*q(s) ds: uniform plus triangular contribution.
        -- Keep the closed full-length form (and uniform P1A arithmetic).
        if qa==qb then
            add_transverse(fe,{L/2,L^2/12,L/2,-L^2/12},qa)
        else
            add_transverse(fe,{L*(7*qa+3*qb)/20,L^2*(3*qa+2*qb)/60,
                               L*(3*qa+7*qb)/20,-L^2*(2*qa+3*qb)/60},1)
        end
    else
        -- H is cubic and q linear: 3-point Gauss-Legendre integrates the
        -- degree-4 product exactly, without subtracting close antiderivatives.
        local half=(b-a)/2
        local z=math.sqrt(3/5)
        local points,weights={-z,0,z},{5/9,8/9,5/9}
        for k=1,3 do
            local t=(points[k]+1)/2
            local shape=hermite(L,a+(b-a)*t)
            add_transverse(fe,shape,half*weights[k]*(qa+(qb-qa)*t))
        end
    end
end

-- Static release condensation, r = released local rotations, c = retained:
-- k*=k_cc-k_cr inv(k_rr) k_rc; f*=f_c-k_cr inv(k_rr) f_r.
-- Embed in six DOFs with exactly zero rows/columns at released rotations.
-- Keep the originals to reconstruct theta_r=inv(k_rr)*(f_r-k_rc*u_c).
local function condense(kl,fe,hinge_i,hinge_j)
    if not hinge_i and not hinge_j then return kl,fe end
    local r,c={},{}
    if hinge_i then r[#r+1]=3 end
    if hinge_j then r[#r+1]=6 end
    for i=1,6 do if not (i==3 and hinge_i or i==6 and hinge_j) then c[#c+1]=i end end
    local inv
    if #r==1 then inv={{1/kl[r[1]][r[1]]}}
    else
        local a,b,d=kl[3][3],kl[3][6],kl[6][6]
        local scale=math.max(math.abs(a),math.abs(b),math.abs(d))
        a,b,d=a/scale,b/scale,d/scale
        local den=(a*d-b*b)*scale
        inv={{d/den,-b/den},{-b/den,a/den}}
    end
    local ks,fs=zeros(6,6),vector(6)
    fs.correction=vector(6)
    for _,i in ipairs(c) do
        local value,low=fe[i],fe.correction[i]
        for a,ra in ipairs(r) do for b,rb in ipairs(r) do
            value,low=compensated_add(value,low,-kl[i][ra]*inv[a][b]*(fe[rb]+fe.correction[rb]))
        end end
        fs[i]=value+low;fs.correction[i]=(value-fs[i])+low
        for _,j in ipairs(c) do if j>=i then
            local v=kl[i][j]
            for a,ra in ipairs(r) do for b,rb in ipairs(r) do v=v-kl[i][ra]*inv[a][b]*kl[rb][j] end end
            -- Both releases leave ONLY the axial stiffness, exactly. Do not
            -- retain roundoff-sized transverse stiffness as a false restraint.
            if hinge_i and hinge_j and i~=1 and i~=4 then v=0 end
            ks[i][j]=v;ks[j][i]=v
        end end
    end
    return ks,fs,{r=r,c=c,inv=inv}
end
-- Zero-energy kinematics are independent of EA/EI. For released models, rank
-- the axial/chord-rotation constraints (row normalized, tolerance 1e-12).
-- This distinguishes a physical hinge mechanism from an ill-conditioned
-- stiffness with positive but disparate rigidities or spring constants.
local function check_hinge_kinematics(members,free,springs)
    local has_hinge=false
    for _,m in ipairs(members) do if m.hinge_i or m.hinge_j then has_hinge=true end end
    if not has_hinge then return end
    local rows={}
    local function add(full)
        local row,scale={},0
        for i,d in ipairs(free) do row[i]=full[d] or 0;scale=math.max(scale,math.abs(row[i])) end
        if scale>0 then
            for i=1,#free do row[i]=row[i]/scale end
            rows[#rows+1]=row
        end
    end
    for _,m in ipairs(members) do
        local i,j=3*m.i,3*m.j
        add({[i-2]=-m.c,[i-1]=-m.s,[j-2]=m.c,[j-1]=m.s})
        for _,endnode in ipairs{1,2} do
            if not (endnode==1 and m.hinge_i or endnode==2 and m.hinge_j) then
                local row={[i-2]=-m.s/m.L,[i-1]=m.c/m.L,[j-2]=m.s/m.L,[j-1]=-m.c/m.L}
                row[endnode==1 and i or j]=1;add(row)
            end
        end
    end
    for d in pairs(springs) do add({[d]=1}) end
    local rank,missing=0,nil
    for col=1,#free do
        local pivot,best=nil,0
        for i=rank+1,#rows do
            if math.abs(rows[i][col])>best then best=math.abs(rows[i][col]);pivot=i end
        end
        if best>1e-12 then
            rank=rank+1;rows[rank],rows[pivot]=rows[pivot],rows[rank]
            for i=rank+1,#rows do
                local factor=rows[i][col]/rows[rank][col]
                for j=col,#free do rows[i][j]=rows[i][j]-factor*rows[rank][j] end
            end
        else missing=missing or free[col] end
    end
    if rank<#free then error('mechanism: hinge kinematics at '..dof_label(missing),0) end
end

local function assemble(model)
    fields(model,{nodes=true,members=true,supports=true,nodal_loads=true,member_loads=true},'model')
    if type(model.nodes)~='table' or #model.nodes==0 or
       type(model.members)~='table' or #model.members==0 then error('empty model',0) end
    local nodes,members={},{}
    for i,n in ipairs(model.nodes) do
        fields(n,{x=true,y=true},'node')
        nodes[i]={x=require_number(n.x,'node x'),y=require_number(n.y,'node y')}
    end
    if #nodes>MAX_NODES then error('model too large for handheld',0) end
    local nn=#nodes
    for i,m in ipairs(model.members) do
        fields(m,{i=true,j=true,EI=true,EA=true,hinge_i=true,hinge_j=true,alphaT=true,h=true},'member')
        for _,key in ipairs{'hinge_i','hinge_j'} do
            if m[key]~=nil and type(m[key])~='boolean' then error('invalid '..key,0) end
        end
        local ni,nj=node_index(m.i,nn),node_index(m.j,nn)
        local EI,EA=require_number(m.EI,'EI'),require_number(m.EA,'EA')
        local dx,dy=nodes[nj].x-nodes[ni].x,nodes[nj].y-nodes[ni].y
        local L=math.sqrt(dx*dx+dy*dy)
        if not finite(L) or L<=0 or EI<=0 or EA<=0 then error('invalid member geometry or rigidity',0) end
        members[i]={i=ni,j=nj,EI=EI,EA=EA,L=L,c=dx/L,s=dy/L,
                    q=0,kappa=0,hinge_i=m.hinge_i,hinge_j=m.hinge_j,alphaT=m.alphaT,h=m.h,
                    points={},moments={},distributed={},cuts={0,L},elements={}}
    end
    for _,load in ipairs(model.member_loads or {}) do
        if type(load)~='table' then error('invalid member load',0) end
        local kind=load.type
        -- Diagnose unsupported TYPE before inspecting its possible fields.
        if kind~='udl' and kind~='point' and kind~='dist' and kind~='moment' and kind~='dT' then
            error('unsupported member load type: '..tostring(kind),0)
        end
        if kind=='udl' then
            fields(load,{member=true,type=true,q=true},'udl load')
        elseif kind=='dist' then
            fields(load,{member=true,type=true,a=true,b=true,q1=true,q2=true},'dist load')
        elseif kind=='point' then
            fields(load,{member=true,type=true,a=true,P=true},'point load')
        elseif kind=='moment' then
            fields(load,{member=true,type=true,a=true,M=true},'moment load')
        else
            fields(load,{member=true,type=true,dT=true},'dT load')
        end
        local mi=load.member
        if not finite(mi) or mi%1~=0 or not members[mi] then error('invalid member index',0) end
        local m=members[mi]
        if kind=='udl' then
            m.q=m.q+require_number(load.q,'q')
        elseif kind=='dT' then
            if not finite(m.alphaT) or m.alphaT<=0 or not finite(m.h) or m.h<=0 then
                error('dT requires positive finite alphaT and h on member '..mi,0)
            end
            m.kappa=m.kappa+m.alphaT*require_number(load.dT,'dT')/m.h
        else
            local a=require_number(load.a,kind..' a')
            if a<0 or a>m.L then error(kind..' a outside member',0) end
            if kind=='dist' then
                local b=require_number(load.b,'dist b')
                if b<=a or b>m.L then error('invalid dist interval: require 0 <= a < b <= L',0) end
                m.distributed[#m.distributed+1]={left={a=a},right={a=b},
                    q1=require_number(load.q1,'q1'),q2=require_number(load.q2,'q2')}
            elseif kind=='point' then
                m.points[#m.points+1]={a=a,position=a,P=require_number(load.P,'P')}
            else
                m.moments[#m.moments+1]={a=a,M=require_number(load.M,'M')}
            end
        end
    end
    local elements={}
    for mi,m in ipairs(members) do
        -- Cuts are recovery coordinates only. No snapping, merging or nodes:
        -- one user member is always ONE element, independent of its loads.
        local positions={0,m.L}
        m.point_positions={}
        for _,p in ipairs(m.points) do
            positions[#positions+1]=p.a;m.point_positions[p.a]=true
        end
        for _,p in ipairs(m.moments) do
            positions[#positions+1]=p.a;m.point_positions[p.a]=true
        end
        for _,d in ipairs(m.distributed) do
            positions[#positions+1]=d.left.a;positions[#positions+1]=d.right.a
        end
        table.sort(positions)
        local cuts={}
        for _,a in ipairs(positions) do
            if cuts[#cuts]~=a then cuts[#cuts+1]=a end
        end
        m.cuts=cuts
        local L=m.L
        local fe=vector(6)
        add_line_load(fe,L,0,L,m.q,m.q)
        for _,d in ipairs(m.distributed) do
            add_line_load(fe,L,d.left.a,d.right.a,d.q1,d.q2)
        end
        for _,p in ipairs(m.points) do
            local H=hermite(L,p.a)
            -- Ni+Nj=1: form the large force as P minus the small force,
            -- keeping its low part instead of rounding P*(1-small) twice.
            if p.a<=L/2 then
                add_component(fe,2,p.P);add_component(fe,2,-p.P*H[3]);add_component(fe,5,p.P*H[3])
            else
                add_component(fe,5,p.P);add_component(fe,5,-p.P*H[1]);add_component(fe,2,p.P*H[1])
            end
            add_component(fe,3,p.P*H[2]);add_component(fe,6,p.P*H[4])
        end
        for _,p in ipairs(m.moments) do
            local _,derivative=hermite(L,p.a)
            add_transverse(fe,derivative,p.M)
        end
        -- M=EI*(w''+kappa_T). Integrating B^T*EI*kappa gives internal
        -- nodal moments (-EI*kappa,+EI*kappa). Since f=k*u-fe, the thermal
        -- consistent load has the opposite signs: fe[3]=+, fe[6]=-.
        add_component(fe,3,m.EI*m.kappa);add_component(fe,6,-m.EI*m.kappa)
        for k=1,6 do
            local value=fe[k]+fe.correction[k]
            fe.correction[k]=(fe[k]-value)+fe.correction[k];fe[k]=value
        end
        local ni,nj=m.i,m.j
        local T=Frame.transformation(m.c,m.s)
        local kl=Frame.local_k(L,m.EA,m.EI)
        local ks,fs,release=condense(kl,fe,m.hinge_i,m.hinge_j)
        local el={member=mi,L=L,EI=m.EI,T=T,kl=ks,kg=rotate_k(ks,T),fe=fs,
                  full_kl=kl,full_fe=fe,release=release,
                  map={3*ni-2,3*ni-1,3*ni,3*nj-2,3*nj-1,3*nj}}
        elements[mi]=el;m.elements={el}
    end
    local nd=3*#nodes
    local K,F=zeros(nd,nd),vector(nd)
    local applied={Fx=0,Fy=0,Mz=0,scale=0}
    local function external(node,Fx,Fy,Mz)
        local n=nodes[node]
        local mom=n.x*Fy-n.y*Fx+Mz
        applied.Fx=applied.Fx+Fx;applied.Fy=applied.Fy+Fy;applied.Mz=applied.Mz+mom
        applied.scale=math.max(applied.scale,math.abs(Fx),math.abs(Fy),math.abs(mom),math.abs(Mz))
        F[3*node-2]=F[3*node-2]+Fx;F[3*node-1]=F[3*node-1]+Fy;F[3*node]=F[3*node]+Mz
    end
    for _,load in ipairs(model.nodal_loads or {}) do
        fields(load,{node=true,Fx=true,Fy=true,M=true},'nodal load')
        external(node_index(load.node,nn),require_number(load.Fx or 0,'Fx'),
                 require_number(load.Fy or 0,'Fy'),require_number(load.M or 0,'M'))
    end
    for _,m in ipairs(members) do
        -- Member loads already enter F through their consistent vectors.
        -- Here tally their physical resultants independently for equilibrium.
        for _,p in ipairs(m.points) do
            local Fx,Fy=-m.s*p.P,m.c*p.P
            local n=nodes[m.i]
            local mom=(n.x+m.c*p.a)*Fy-(n.y+m.s*p.a)*Fx
            applied.Fx=applied.Fx+Fx;applied.Fy=applied.Fy+Fy;applied.Mz=applied.Mz+mom
            applied.scale=math.max(applied.scale,math.abs(Fx),math.abs(Fy),math.abs(mom))
        end
        for _,p in ipairs(m.moments) do
            applied.Mz=applied.Mz+p.M;applied.scale=math.max(applied.scale,math.abs(p.M))
        end
        local function line_resultant(a,b,qa,qb)
            local length=b-a
            local R=(qa+qb)*length/2
            -- Signed first moment integral s*q(s) ds, equivalent to R*s_c
            -- when R~=0. No centroid division: R=0 can leave a pure couple.
            local J=a*R+length^2*(qa+2*qb)/6
            local Fx,Fy=-m.s*R,m.c*R
            local origin=nodes[m.i]
            local mom=origin.x*Fy-origin.y*Fx+J
            applied.Fx=applied.Fx+Fx;applied.Fy=applied.Fy+Fy;applied.Mz=applied.Mz+mom
            applied.scale=math.max(applied.scale,math.abs(Fx),math.abs(Fy),math.abs(mom))
        end
        -- Use original user positions; no geometric alteration of loads.
        line_resultant(0,m.L,m.q,m.q)
        for _,d in ipairs(m.distributed) do
            line_resultant(d.left.a,d.right.a,d.q1,d.q2)
        end
    end
    for _,el in ipairs(elements) do
        for i=1,6 do
            local d=el.map[i]
            for a=1,6 do F[d]=F[d]+el.T[a][i]*el.fe[a] end
            for j=1,6 do K[d][el.map[j]]=K[d][el.map[j]]+el.kg[i][j] end
        end
    end
    local fixed,prescribed,springs={},{},{}
    local spring_names={'kx','ky','kr'}
    local imposed_names={'dx','dy','drz'}
    for _,support in ipairs(model.supports or {}) do
        fields(support,{node=true,ux=true,uy=true,rz=true,kx=true,ky=true,kr=true,dx=true,dy=true,drz=true},'support')
        local ni=node_index(support.node,nn)
        for j,name in ipairs(dof_names) do
            local d=3*ni-3+j
            local v=support[name]
            if v~=nil and type(v)~='boolean' then error('unsupported prescribed displacement '..name,0) end
            if v then fixed[d]=true end
            local spring=support[spring_names[j]]
            if spring~=nil then
                if not finite(spring) or spring<=0 then error('spring must be positive and finite: '..dof_label(d),0) end
                springs[d]=(springs[d] or 0)+spring
            end
            local imposed=support[imposed_names[j]]
            if imposed~=nil then
                require_number(imposed,'prescribed displacement '..name)
                if prescribed[d]~=nil and prescribed[d]~=imposed then error('conflicting prescribed displacement '..dof_label(d),0) end
                prescribed[d]=imposed
            end
        end
    end
    for d,value in pairs(prescribed) do
        -- Zero defaults do not impose motion on an unrestricted DOF.
        if not fixed[d] and value~=0 then error('prescribed displacement on unrestricted '..dof_label(d),0) end
    end
    for d,k in pairs(springs) do
        if fixed[d] then error('spring and restraint on same DOF: '..dof_label(d),0) end
        K[d][d]=K[d][d]+k
    end
    local connected,rotation_active={},{}
    for _,m in ipairs(members) do
        connected[m.i]=true;connected[m.j]=true
        if not m.hinge_i then rotation_active[m.i]=true end
        if not m.hinge_j then rotation_active[m.j]=true end
    end
    -- A joint rotation disconnected by ALL incident releases is a redundant
    -- coordinate, not a physical mechanism. Fix it internally to zero; a
    -- nodal moment there has no load path and must instead fail as mechanism.
    -- Record these node indices in sol.inactive_rotations for inspection.
    local inactive_rotations={}
    for i=1,nn do
        local d=3*i
        if connected[i] and not rotation_active[i] and not fixed[d] and not springs[d] then
            if F[d]~=0 then error('mechanism: nodal moment at released '..dof_label(d),0) end
            fixed[d]=true;prescribed[d]=0;inactive_rotations[#inactive_rotations+1]=i
        end
    end
    local free={}
    for i=1,nd do
        if not finite(F[i]) then error('ill-conditioned: non-finite load',0) end
        for j=1,nd do
            if not finite(K[i][j]) then error('ill-conditioned: non-finite stiffness',0) end
        end
        if not fixed[i] then free[#free+1]=i end
    end
    check_hinge_kinematics(members,free,springs)
    return {nodes=nodes,members=members,elements=elements,K=K,F=F,ndof=nd,
            fixed=fixed,prescribed=prescribed,springs=springs,inactive_rotations=inactive_rotations,
            free=free,applied=applied}
end
-- Dense LU, partial pivoting by |a_ik| / max_j |original a_ij|.
-- Exactly zero row/column or pivot => mechanism; nonzero relative pivot below
-- 1e-12 => ill-conditioned. Row scaling avoids comparing EA directly to EI.
local function linear_solve(sol)
    local free,K,F=sol.free,sol.K,sol.F
    local n=#free
    local a,scale=zeros(n,n+1),{}
    for i=1,n do
        local rowmax=0
        for j=1,n do a[i][j]=K[free[i]][free[j]];rowmax=math.max(rowmax,math.abs(a[i][j])) end
        if rowmax==0 then error('mechanism: zero stiffness at '..dof_label(free[i]),0) end
        local rhs=F[free[i]]
        for d=1,sol.ndof do
            local value=sol.prescribed[d] or 0
            if sol.fixed[d] and value~=0 then rhs=rhs-K[free[i]][d]*value end
        end
        a[i][n+1]=rhs;scale[i]=rowmax
    end
    for k=1,n do
        local imax,score=k,-1
        for i=k,n do
            local p=math.abs(a[i][k])/scale[i]
            if not finite(p) then error('ill-conditioned: non-finite factorization',0) end
            if p>score then score=p;imax=i end
        end
        if score==0 then error('mechanism: zero pivot at '..dof_label(free[k]),0) end
        if score<PIVOT_TOL then error('ill-conditioned: small relative pivot at '..dof_label(free[k]),0) end
        a[k],a[imax]=a[imax],a[k];scale[k],scale[imax]=scale[imax],scale[k]
        for i=k+1,n do
            local fac=a[i][k]/a[k][k]
            a[i][k]=0
            for j=k+1,n+1 do a[i][j]=a[i][j]-fac*a[k][j] end
        end
    end
    local x={}
    for i=n,1,-1 do
        local v=a[i][n+1]
        for j=i+1,n do v=v-a[i][j]*x[j] end
        x[i]=v/a[i][i]
        if not finite(x[i]) then error('ill-conditioned: non-finite solution',0) end
    end
    return x
end
-- Exact polynomials on a RECOVERY span, x measured from its left cut.
-- w''=M/EI-kappa_T, integrated from preceding w and rotation. Horner evaluation
-- keeps all powers local to the span; no new stiffness matrix is introduced.
local function span_value(span,x)
    local V=span.V+x*(span.qa+x*span.g/2)
    local M=span.M+x*(span.V+x*(span.qa/2+x*span.g/6))
    local mechanical=span.M-span.EI*(span.kappa or 0)
    local theta=span.theta+x*(mechanical+x*(span.V/2+x*(span.qa/6+x*span.g/24)))/span.EI
    local w=span.w+x*(span.theta+x*(mechanical/2+x*(span.V/6+x*(span.qa/24+x*span.g/120)))/span.EI)
    return V,M,w,theta
end
-- The ONLY nodal -> diagram conversion. Starting at i: N=-Ni, V=Vi,
-- M=-Mi. Crossing a point adds P to V; crossing a CCW moment subtracts M0
-- from M. Integrate dV/ds=q, dM/ds=V, w''=M/EI-kappa_T between load cuts.
-- Loads AT i are crossed before the first span; loads AT j act outside its
-- left limit. Thus diagrams still describe the physical interior of a member.
local function nodal_to_diagram(el,m)
    local V,Vlow=el.f[2],el.f_correction[2]
    local M,Mlow=-el.f[3],-el.f_correction[3]
    local w,theta=el.u[2],el.u[3]
    el.N=-el.f[1];el.spans={}
    for k=1,#m.cuts-1 do
        local a,b=m.cuts[k],m.cuts[k+1]
        for _,p in ipairs(m.points) do if p.a==a then V,Vlow=compensated_add(V,Vlow,p.P) end end
        for _,p in ipairs(m.moments) do if p.a==a then M,Mlow=compensated_add(M,Mlow,-p.M) end end
        local qa,g=m.q,0
        for _,d in ipairs(m.distributed) do
            local da,db=d.left.a,d.right.a
            if a>=da and b<=db then
                local gradient=(d.q2-d.q1)/(db-da)
                qa=qa+d.q1+gradient*(a-da);g=g+gradient
            end
        end
        local span={x0=a,x1=b,L=b-a,EI=el.EI,V=V+Vlow,M=M+Mlow,w=w,theta=theta,qa=qa,g=g,kappa=m.kappa}
        el.spans[#el.spans+1]=span
        local h=span.L
        local _,_,next_w,next_theta=span_value(span,h)
        M,Mlow=compensated_add(M,Mlow,h*(Vlow+V+h*(qa/2+h*g/6)))
        V,Vlow=compensated_add(V,Vlow,h*(qa+h*g/2))
        w,theta=next_w,next_theta
    end
    return w,theta
end
-- Isolate stationary points on each span with the P1A 64-interval rule.
local function roots_on_span(span,value,visit)
    local a,fa=0,value(0)
    for k=1,64 do
        local b=span.L*k/64
        local fb=value(b)
        if fa==0 then visit(a) end
        if fb==0 then visit(b) end
        if fa~=0 and fb~=0 and (fa<0)~=(fb<0) then
            local left,right,fleft=a,b,fa
            while right-left>1e-12*span.L do
                local mid=(left+right)/2
                local fm=value(mid)
                if fm==0 then left=mid;right=mid
                elseif (fm<0)==(fleft<0) then left=mid;fleft=fm else right=mid end
            end
            visit((left+right)/2)
        end
        a,fa=b,fb
    end
end
local function compatibility(el,w_end,theta_end,member)
    -- End-force reference prevents a vanishing response from setting the
    -- entire error scale for loads approaching a rigid support.
    local L,EI=el.L,el.EI
    local F_ends=math.max(math.abs(el.f[2]),math.abs(el.f[5]),math.abs(el.f[3])/L,math.abs(el.f[6])/L)
    local F_loads=math.abs(member.q)*L+EI*math.abs(member.kappa)/L
    for _,p in ipairs(member.points) do F_loads=F_loads+math.abs(p.P) end
    for _,p in ipairs(member.moments) do F_loads=F_loads+math.abs(p.M)/L end
    for _,d in ipairs(member.distributed) do
        F_loads=F_loads+math.max(math.abs(d.q1),math.abs(d.q2))*(d.right.a-d.left.a)
    end
    local F=math.max(F_ends,F_loads)
    local raw_w_scale=math.max(math.abs(el.u[2]),math.abs(el.u[5]))
    local raw_theta_scale=math.max(math.abs(el.u[3]),math.abs(el.u[6]))
    local w_scale=math.max(math.abs(el.u[2]),math.abs(el.u[5]),1e-6*F*L^3/EI)
    local theta_scale=math.max(math.abs(el.u[3]),math.abs(el.u[6]),1e-6*F*L^2/EI)
    local function candidate(span,x)
        local _,_,w,theta=span_value(span,x)
        if not finite(w) or not finite(theta) then error('ill-conditioned: non-finite recovery',0) end
        w_scale=math.max(w_scale,math.abs(w));theta_scale=math.max(theta_scale,math.abs(theta))
        raw_w_scale=math.max(raw_w_scale,math.abs(w));raw_theta_scale=math.max(raw_theta_scale,math.abs(theta))
    end
    for _,span in ipairs(el.spans) do
        local function visit(x) candidate(span,x) end
        candidate(span,0);candidate(span,span.L)
        roots_on_span(span,function(x) local _,_,_,t=span_value(span,x);return t end,visit)
        roots_on_span(span,function(x) local _,M=span_value(span,x);return M-span.EI*(span.kappa or 0) end,visit)
    end
    local dw,dt=w_end-el.u[5],theta_end-el.u[6]
    local rw=w_scale==0 and (dw==0 and 0 or math.huge) or math.abs(dw)/w_scale
    local rt=theta_scale==0 and (dt==0 and 0 or math.huge) or math.abs(dt)/theta_scale
    local raw_w=raw_w_scale==0 and (dw==0 and 0 or math.huge) or math.abs(dw)/raw_w_scale
    local raw_theta=raw_theta_scale==0 and (dt==0 and 0 or math.huge) or math.abs(dt)/raw_theta_scale
    return {w_residual=dw,rz_residual=dt,w_scale=w_scale,rz_scale=theta_scale,
            relative=math.max(rw,rt),relative_raw=math.max(raw_w,raw_theta)}
end

local function solve(model)
    local sol=assemble(model)
    local uf=linear_solve(sol)
    local u=vector(sol.ndof)
    for d,value in pairs(sol.prescribed) do if sol.fixed[d] then u[d]=value end end
    for i,d in ipairs(sol.free) do u[d]=uf[i] end
    sol.u=u
    local residual=vector(sol.ndof)
    for i=1,sol.ndof do
        local v=-sol.F[i]
        for j=1,sol.ndof do v=v+sol.K[i][j]*u[j] end
        if not finite(v) then error('ill-conditioned: non-finite residual',0) end
        residual[i]=v
    end
    sol.reactions={}
    local Fx,Fy,Mz=sol.applied.Fx,sol.applied.Fy,sol.applied.Mz
    local free_residual=0
    for _,d in ipairs(sol.free) do free_residual=math.max(free_residual,math.abs(residual[d])) end
    for i,node in ipairs(sol.nodes) do
        -- Spring reaction is the force ON the structure, -k*u. K already
        -- includes +k on its diagonal for the free-DOF residual check.
        local rx=sol.fixed[3*i-2] and residual[3*i-2] or -(sol.springs[3*i-2] or 0)*u[3*i-2]
        local ry=sol.fixed[3*i-1] and residual[3*i-1] or -(sol.springs[3*i-1] or 0)*u[3*i-1]
        local mz=sol.fixed[3*i] and residual[3*i] or -(sol.springs[3*i] or 0)*u[3*i]
        sol.reactions[i]={Rx=rx,Ry=ry,Mz=mz}
        Fx=Fx+rx;Fy=Fy+ry;Mz=Mz+node.x*ry-node.y*rx+mz
    end
    -- Zero applied load uses scale=1 solely to define normalized zero checks.
    local scale=sol.applied.scale>0 and sol.applied.scale or 1
    local eq=math.max(math.abs(Fx),math.abs(Fy),math.abs(Mz))
    sol.checks={Fx=Fx,Fy=Fy,Mz=Mz,free_residual=free_residual,scale=scale,
                equilibrium_relative=eq/scale,residual_relative=free_residual/scale,tolerance=CHECK_TOL}
    if not finite(eq) or eq/scale>CHECK_TOL then error('global equilibrium failed',0) end
    if free_residual/scale>CHECK_TOL then error('free DOF residual failed',0) end
    sol.checks.compatibility_relative=0
    sol.checks.compatibility_members={}
    for _,el in ipairs(sol.elements) do
        el.u=vector(6);el.f=vector(6);el.f_correction=vector(6)
        for i=1,6 do for j=1,6 do el.u[i]=el.u[i]+el.T[i][j]*u[el.map[j]] end end
        if el.release then
            local release,rhs=el.release,{}
            for a,r in ipairs(release.r) do
                local value,low=el.full_fe[r],el.full_fe.correction[r]
                for _,c in ipairs(release.c) do value,low=compensated_add(value,low,-el.full_kl[r][c]*el.u[c]) end
                rhs[a]=value+low
            end
            for a,r in ipairs(release.r) do
                el.u[r]=0
                for b=1,#release.r do el.u[r]=el.u[r]+release.inv[a][b]*rhs[b] end
            end
        end
        -- Use CONDENSED k and fe for end forces; released moments are zero.
        -- Actual reconstructed member rotations above drive w and compatibility.
        -- Essential: subtract the consistent fixed-end load vector.
        for i=1,6 do
            local value,low=-el.fe[i],-el.fe.correction[i]
            for j=1,6 do value,low=compensated_add(value,low,el.kl[i][j]*el.u[j]) end
            el.f[i]=value+low;el.f_correction[i]=(value-el.f[i])+low
            if not finite(el.f[i]) then error('ill-conditioned: non-finite end forces',0) end
        end
        local w_end,theta_end=nodal_to_diagram(el,sol.members[el.member])
        local check=compatibility(el,w_end,theta_end,sol.members[el.member])
        sol.checks.compatibility_members[el.member]=check
        sol.checks.compatibility_relative=math.max(sol.checks.compatibility_relative,check.relative)
        if check.relative>CHECK_TOL then error(string.format('member compatibility failed: member %d (relative %.6g, dw %.6g, drz %.6g, w scale %.6g, rz scale %.6g)',el.member,check.relative,check.w_residual,check.rz_residual,check.w_scale,check.rz_scale),0) end
    end
    return sol
end
function Frame.solve(model)
    local ok,result=pcall(solve,model)
    if ok then return result end
    return nil,result
end

local function member_result(sol,member)
    if not finite(member) or member%1~=0 or not sol.members[member] then error('invalid member index',0) end
    return sol.members[member]
end
local function at_span(el,span,x,s)
    local V,M,w=span_value(span,x)
    local t=s/el.L
    return {N=el.N,V=V,M=M,w=w,u=(1-t)*el.u[1]+t*el.u[4]}
end
function Frame.at(sol,member,s,side)
    local m=member_result(sol,member)
    if not finite(s) or s< -1e-12*m.L or s>m.L*(1+1e-12) then error('s outside member',0) end
    s=math.max(0,math.min(m.L,s))
    if side~=nil and side~='left' and side~='right' then error('invalid side',0) end
    if m.point_positions[s] and side==nil then error('side required at point or moment load node',0) end
    if s==0 and side=='left' or s==m.L and side=='right' then error('side outside member',0) end
    local el=m.elements[1]
    -- Exact lateral limit at each recovery cut; never sample s +/- epsilon.
    for _,span in ipairs(el.spans) do
        if s==span.x0 and side~='left' then return at_span(el,span,0,s) end
        if s==span.x1 and side~='right' then return at_span(el,span,span.L,s) end
        if s>span.x0 and s<span.x1 then return at_span(el,span,s-span.x0,s) end
    end
    error('no recovery span at s',0)
end
-- Stable quadratic roots: Q=-0.5*(b+sign(b)*sqrt(D)); roots Q/a,c/Q.
-- Avoids subtracting nearly equal values for the small root. Scale first.
local function quadratic_roots(a,b,c)
    local scale=math.max(math.abs(a),math.abs(b),math.abs(c))
    if scale==0 then return {} end
    a,b,c=a/scale,b/scale,c/scale
    if a==0 then
        if b==0 then return {} end
        return {-c/b}
    end
    local disc=b*b-4*a*c
    if disc<0 then return {} end
    local sign=b<0 and -1 or 1
    local Q=-0.5*(b+sign*math.sqrt(disc))
    if Q==0 then return {-b/(2*a)} end
    return {Q/a,c/Q}
end
function Frame.moment_extrema(sol,member)
    local m=member_result(sol,member)
    local lo,xlo,hi,xhi=math.huge,0,-math.huge,0
    for _,span in ipairs(m.elements[1].spans) do
        local candidates={0,span.L}
        for _,t in ipairs(quadratic_roots(span.g*span.L^2/2,span.qa*span.L,span.V)) do
            if t>0 and t<1 then candidates[#candidates+1]=t*span.L end
        end
        for _,s in ipairs(candidates) do
            local _,v=span_value(span,s)
            if v<lo then lo=v;xlo=span.x0+s end
            if v>hi then hi=v;xhi=span.x0+s end
        end
    end
    return lo,xlo,hi,xhi
end
function Frame.deflection_extrema(sol,member)
    local m=member_result(sol,member)
    local lo,xlo,hi,xhi=math.huge,0,-math.huge,0
    for _,span in ipairs(m.elements[1].spans) do
        local function candidate(x)
            local _,_,w=span_value(span,x)
            if w<lo then lo=w;xlo=span.x0+x end
            if w>hi then hi=w;xhi=span.x0+x end
        end
        candidate(0);candidate(span.L)
        roots_on_span(span,function(x) local _,_,_,theta=span_value(span,x);return theta end,candidate)
    end
    return lo,xlo,hi,xhi
end

-- Superposition of already recovered solutions; no assembly or linear solve.
function Frame.combine(solutions,factors)
    local function incompatible(reason) error('incompatible solutions: '..reason,0) end
    local function copy(value,memo)
        if type(value)~='table' then return value end
        memo=memo or {}
        if memo[value] then return memo[value] end
        local out={};memo[value]=out
        for k,v in pairs(value) do out[k]=copy(v,memo) end
        return out
    end
    local function same(a,b)
        if type(a)~=type(b) then return false end
        if type(a)~='table' then return a==b end
        for k,v in pairs(a) do if not same(v,b[k]) then return false end end
        for k in pairs(b) do if a[k]==nil then return false end end
        return true
    end
    local function combine()
        if type(solutions)~='table' or type(factors)~='table' or #solutions==0 or #solutions~=#factors then
            incompatible('solution/factor counts')
        end
        local base=solutions[1]
        if type(base)~='table' or not base.u or not base.reactions or not base.members then incompatible('not a solved model') end
        for k=1,#solutions do
            local s=solutions[k]
            if not finite(factors[k]) then incompatible('non-finite factor') end
            if type(s)~='table' or not s.u or not s.reactions or not s.members then incompatible('not a solved model') end
            if not same(base.nodes,s.nodes) then incompatible('nodes') end
            for _,name in ipairs{'ndof','fixed','prescribed','springs','free','inactive_rotations'} do
                if not same(base[name],s[name]) then incompatible(name) end
            end
            if #base.members~=#s.members then incompatible('member count') end
            for i,m in ipairs(base.members) do
                local other=s.members[i]
                for _,key in ipairs{'i','j','L','c','s','EI','EA','hinge_i','hinge_j','alphaT','h','cuts'} do
                    if not same(m[key],other[key]) then incompatible('member '..i..' '..key) end
                end
                local a,b=m.elements[1],other.elements[1]
                if not a.spans or not b.spans or #a.spans~=#b.spans then incompatible('recovery spans') end
                for j,span in ipairs(a.spans) do
                    for _,key in ipairs{'x0','x1','L','EI'} do
                        if span[key]~=b.spans[j][key] then incompatible('recovery '..key) end
                    end
                end
            end
        end
        local out=copy(base)
        if #solutions==1 and factors[1]==1 then return out end
        local function sum(get)
            local value,low=0,0
            for k,s in ipairs(solutions) do value,low=compensated_add(value,low,factors[k]*get(s)) end
            value=value+low
            if not finite(value) then incompatible('non-finite combined response') end
            return value
        end
        local function vector_sum(target,get)
            for j=1,#target do
                target[j]=sum(function(s) return get(s)[j] end)
            end
            if target.correction then
                for j=1,#target.correction do
                    target.correction[j]=sum(function(s) return get(s).correction[j] end)
                end
            end
        end
        vector_sum(out.u,function(s) return s.u end)
        vector_sum(out.F,function(s) return s.F end)
        for d in pairs(out.prescribed) do out.prescribed[d]=sum(function(s) return s.prescribed[d] end) end
        for _,key in ipairs{'Fx','Fy','Mz'} do out.applied[key]=sum(function(s) return s.applied[key] end) end
        out.applied.scale=0
        for k,s in ipairs(solutions) do out.applied.scale=out.applied.scale+math.abs(factors[k])*s.applied.scale end
        for i,r in ipairs(out.reactions) do
            for _,key in ipairs{'Rx','Ry','Mz'} do r[key]=sum(function(s) return s.reactions[i][key] end) end
        end
        for i,m in ipairs(out.members) do
            m.q=sum(function(s) return s.members[i].q end)
            m.kappa=sum(function(s) return s.members[i].kappa end)
            m.points={};m.moments={};m.distributed={};m.point_positions={}
            for k,s in ipairs(solutions) do
                local source=s.members[i]
                for x in pairs(source.point_positions) do m.point_positions[x]=true end
                for _,list in ipairs{{'points','P'},{'moments','M'},{'distributed','q1','q2'}} do
                    for _,load in ipairs(source[list[1]]) do
                        local item=copy(load)
                        for j=2,#list do item[list[j]]=item[list[j]]*factors[k] end
                        m[list[1]][#m[list[1]]+1]=item
                    end
                end
            end
            local el=m.elements[1]
            for _,key in ipairs{'u','f','f_correction','fe','full_fe'} do
                vector_sum(el[key],function(s) return s.members[i].elements[1][key] end)
            end
            el.N=sum(function(s) return s.members[i].elements[1].N end)
            for j,span in ipairs(el.spans) do
                for _,key in ipairs{'V','M','w','theta','qa','g','kappa'} do
                    span[key]=sum(function(s) return s.members[i].elements[1].spans[j][key] end)
                end
            end
        end
        -- Source diagnostics certify their own solves, not this superposition.
        out.checks=nil
        return out
    end
    local ok,result=pcall(combine)
    if ok then return result end
    local message=tostring(result)
    if not string.find(message,'incompatible solutions: ',1,true) then message='incompatible solutions: malformed solution' end
    return nil,message
end


-- Permanent beam presets on Frame. Load global Frame before this module.
-- Input L,a in m, EI in kN*m^2; q/P positive DOWN. Physical results:
-- reactions global, M sagging positive, w UP in metres. Summary bx_wmax in mm.
BeamPreset = {}
local Core = assert(Frame,'load Frame before beam_preset.lua')

-- ONLY sign/unit conversion boundary. All other mechanics delegate to Frame.
local function convert(kind,value)
    if kind=='load' then return -value end
    if kind=='mm' then return value*1000 end
    error('invalid conversion',0)
end
local function finite(x)
    return type(x)=='number' and x==x and math.abs(x)<math.huge
end
function BeamPreset.model(p)
    if type(p)~='table' or not finite(p.L) or p.L<=0 or not finite(p.EI) or p.EI<=0
       or not finite(p.q) or not finite(p.P) or not finite(p.a) or p.a<0 or p.a>p.L then
        return nil,'invalid beam dimensions, rigidity or loads'
    end
    if p.support~=1 and p.support~=2 and p.support~=3 and p.support~=4 then
        return nil,'unknown beam preset'
    end
    local loads={{member=1,type='udl',q=convert('load',p.q)}}
    if p.P~=0 then loads[#loads+1]={member=1,type='point',a=p.a,P=convert('load',p.P)} end
    return {nodes={{x=0,y=0},{x=p.L,y=0}},members={{i=1,j=2,EI=p.EI,EA=1000*p.EI/p.L^2}},
        supports={{node=1,ux=true,uy=true,rz=p.support~=1},
                  {node=2,ux=p.support==3,uy=p.support~=2,rz=p.support==3}},member_loads=loads}
end
function BeamPreset.at(sol,x,side)
    x=math.max(0,math.min(sol.parameters.L,x))
    -- Default physical limit at a discontinuity: left, except at x=0 where
    -- only the right/interior limit exists. Callers may explicitly select side.
    return Core.at(sol.frame,1,x,side or (x==0 and 'right' or 'left'))
end
function BeamPreset.moment_extrema(sol)
    local lo,xlo,hi,xhi=Core.moment_extrema(sol.frame,1)
    -- A sum of recovery-span coordinates may exceed an end by one ulp.
    -- Normalize coordinates only; the physical extrema values stay untouched.
    local L=sol.parameters.L
    return {minimum={value=lo,position=math.max(0,math.min(L,xlo))},
            maximum={value=hi,position=math.max(0,math.min(L,xhi))}}
end
function BeamPreset.deflection_extrema(sol)
    local lo,xlo,hi,xhi=Core.deflection_extrema(sol.frame,1)
    local w,x=lo,xlo
    if math.abs(hi)>math.abs(lo) then w,x=hi,xhi end
    return {value=w,absolute=math.abs(w),position=math.max(0,math.min(sol.parameters.L,x))}
end
function BeamPreset.deflection_check(sol,limit,lref_factor)
    limit=limit==300 and 300 or 250
    lref_factor=lref_factor or 1
    local maximum=sol.deflection or BeamPreset.deflection_extrema(sol)
    local lref=lref_factor*sol.parameters.L
    local w=convert('mm',maximum.absolute)
    local mm=convert('mm',lref)
    local ratio=w>0 and mm/w or nil
    local u250,u300=w/(mm/250),w/(mm/300)
    local selected=limit==300 and u300 or u250
    local status='N/A'
    if ratio then status=selected<=1+1e-12 and 'OK' or 'EXCEEDED' end
    return {lref_factor=lref_factor,reference_length=lref,span_deflection_ratio=ratio,
            utilization={L250=u250,L300=u300},selected_limit=limit,status=status}
end
function BeamPreset.summary(sol)
    local p=sol.parameters
    local vabs=0
    local positions={0,p.L}
    if p.P~=0 and p.a>0 and p.a<p.L then positions[#positions+1]=p.a end
    for _,x in ipairs(positions) do
        if x>0 then vabs=math.max(vabs,math.abs(Core.at(sol.frame,1,x,'left').V)) end
        if x<p.L then vabs=math.max(vabs,math.abs(Core.at(sol.frame,1,x,'right').V)) end
    end
    return {bx_mmax=sol.moments.maximum.value,bx_mmin=sol.moments.minimum.value,
            bx_vabs=vabs,bx_wmax=convert('mm',sol.deflection.absolute),bx_xwmax=sol.deflection.position,
            bx_ra=sol.reactions.left.Ry,bx_rb=sol.reactions.right.Ry,bx_ei=p.EI}
end
function BeamPreset.solve(p,limit,lref_factor)
    local model,err=BeamPreset.model(p)
    if not model then return nil,err end
    local frame
    frame,err=Core.solve(model)
    if not frame then return nil,err end
    local result={parameters={L=p.L,q=p.q,P=p.P,a=p.a,EI=p.EI,support=p.support},frame=frame,
                  reactions={left=frame.reactions[1],right=frame.reactions[2]}}
    result.moments=BeamPreset.moment_extrema(result)
    result.deflection=BeamPreset.deflection_extrema(result)
    result.deflection_check=BeamPreset.deflection_check(result,limit,lref_factor)
    result.summary=BeamPreset.summary(result)
    return result
end


-- Continuous single-EI beams on Frame. No UI or CAS namespace (P5A).
-- m, kN, kNm, EI in kN*m^2; g/q and reported deflection positive DOWN.
ContinuousPreset = {MAX_SPANS=5}
local Core=assert(Frame,'load Frame before continuous_preset.lua')
local function convert(value) return -value end -- sole sign boundary
local function finite(x) return type(x)=='number' and x==x and math.abs(x)<math.huge end
local function parameters(p)
    if type(p)~='table' or type(p.spans)~='table' or #p.spans<2 or #p.spans>ContinuousPreset.MAX_SPANS then
        return nil,'expected 2 to '..ContinuousPreset.MAX_SPANS..' spans'
    end
    local out={spans={},EI=p.EI,g=p.g,q=p.q,left=p.left,right=p.right,
        gG_sup=p.gG_sup==nil and 1.35 or p.gG_sup,gG_inf=p.gG_inf==nil and 1 or p.gG_inf,
        gQ=p.gQ==nil and 1.5 or p.gQ,limit=p.limit==nil and 250 or p.limit}
    for i,L in ipairs(p.spans) do
        if not finite(L) or L<=0 then return nil,'invalid span length' end
        out.spans[i]=L
    end
    if not finite(out.EI) or out.EI<=0 then return nil,'invalid EI' end
    if not finite(out.g) or not finite(out.q) then return nil,'invalid uniform load' end
    if (out.left~='PIN' and out.left~='FIX') or (out.right~='PIN' and out.right~='FIX') then return nil,'invalid end support' end
    for _,key in ipairs{'gG_sup','gG_inf','gQ'} do
        if not finite(out[key]) or out[key]<=0 then return nil,'invalid factor '..key end
    end
    if out.limit~=250 and out.limit~=300 then return nil,'invalid deflection limit' end
    return out
end
function ContinuousPreset.model(p,case)
    local p,err=parameters(p)
    if not p then return nil,err end
    local n=#p.spans
    if case~='G' and (not finite(case) or case%1~=0 or case<1 or case>n) then return nil,'invalid load case' end
    local m={nodes={{x=0,y=0}},members={},supports={},member_loads={}}
    local x=0
    for i,L in ipairs(p.spans) do
        x=x+L;m.nodes[i+1]={x=x,y=0}
        m.members[i]={i=i,j=i+1,EI=p.EI,EA=1000*p.EI/L^2}
        m.member_loads[i]={member=i,type='udl',q=convert(case=='G' and p.g or (case==i and p.q or 0))}
    end
    for i=1,n+1 do
        m.supports[i]={node=i,uy=true,ux=i==1 or (i==n+1 and p.right=='FIX'),
            rz=(i==1 and p.left=='FIX') or (i==n+1 and p.right=='FIX')}
    end
    return m
end
-- Stable roots in the unit span coordinate; no sampling or iterative search.
local function roots(a,b,c)
    local scale=math.max(math.abs(a),math.abs(b),math.abs(c))
    if scale==0 then return {} end
    a,b,c=a/scale,b/scale,c/scale
    if c==0 then return b==0 and {} or {-a/b} end
    local d=b*b-4*a*c
    if d<0 then return {} end
    local q=-.5*(b+(b<0 and -1 or 1)*math.sqrt(d))
    if q==0 then return {-b/(2*c)} end
    return {q/c,a/q}
end
local function polynomial(poly,t) return poly[1]+t*(poly[2]+t*poly[3]) end
local function record(value,x,offset,name,gamma)
    return {value=value,absolute=math.abs(value),x=x,position=offset+x,pattern=name,gammaG=gamma}
end
local function update(current,candidate,maximum)
    if not current or (maximum and candidate.value>current.value) or (not maximum and candidate.value<current.value) then return candidate end
    return current
end
local function solve(p)
    local p,err=parameters(p)
    if not p then return nil,err end
    local n=#p.spans
    local bases={}
    for case=0,n do
        local model=assert(ContinuousPreset.model(p,case==0 and 'G' or case))
        local sol,message=Core.solve(model)
        if not sol then return nil,message end
        bases[case+1]=sol
    end
    local out={parameters=p,bases=bases,spans={},supports={},deflection_label='w char.',
        factor_convention={status='OPEN',reference='EN 1990 Annex A1 and applicable NA'}}
    local offsets={0}
    for i,L in ipairs(p.spans) do
        out.spans[i]={length=L,offset=offsets[i],deflection={label='w char.'}}
        offsets[i+1]=offsets[i]+L
    end
    for i=1,n+1 do out.supports[i]={position=offsets[i]} end
    local function moment(v,x,i)
        -- Prescribed PIN boundary zeros; no response/sign recalculation.
        if (i==1 and x==0 and p.left=='PIN') or (i==n and x==p.spans[i] and p.right=='PIN') then return 0 end
        return v
    end
    -- Scalar response envelopes select each contribution independently.
    local function choose(values,maximum)
        local gamma=p.gG_sup
        if (maximum and p.gG_inf*values[1]>gamma*values[1]) or
           (not maximum and p.gG_inf*values[1]<gamma*values[1]) then gamma=p.gG_inf end
        local value=gamma*values[1]
        local weights,names={gamma},{}
        for j=2,#values do
            local active=(maximum and values[j]>0) or (not maximum and values[j]<0)
            weights[j]=active and p.gQ or 0
            if active then value=value+p.gQ*values[j];names[#names+1]=tostring(j-1) end
        end
        return value,#names>0 and table.concat(names,'-') or '-',gamma,weights
    end
    for i,L in ipairs(p.spans) do
        local polys={}
        for j,base in ipairs(bases) do
            local v=Core.at(base,i,0,'right')
            local q=j==1 and p.g or (j-1==i and p.q or 0)
            polys[j]={moment(v.M,0,i),v.V*L,convert(q)*L^2/2}
        end
        local function values_at(t)
            local values={}
            for j,poly in ipairs(polys) do values[j]=moment(polynomial(poly,t),t*L,i) end
            return values
        end
        -- Cuts at every base zero make both the Qi set and the gammaG fixed.
        local cuts={0,1}
        for _,poly in ipairs(polys) do
            for _,t in ipairs(roots(poly[1],poly[2],poly[3])) do
                if t>0 and t<1 then cuts[#cuts+1]=t end
            end
        end
        table.sort(cuts)
        local function candidate(t,maximum)
            local value,name,gamma=choose(values_at(t),maximum)
            local key=maximum and 'Mmax' or 'Mmin'
            out.spans[i][key]=update(out.spans[i][key],record(value,t*L,offsets[i],name,gamma),maximum)
        end
        for k=1,#cuts-1 do
            local left,right=cuts[k],cuts[k+1]
            if right>left then
                for _,maximum in ipairs{true,false} do
                    local _,_,_,weights=choose(values_at((left+right)/2),maximum)
                    local b,c=0,0
                    for j,poly in ipairs(polys) do b=b+weights[j]*poly[2];c=c+weights[j]*poly[3] end
                    candidate(left,maximum);candidate(right,maximum)
                    if c~=0 then
                        local vertex=-b/(2*c)
                        if vertex>left and vertex<right then candidate(vertex,maximum) end
                    end
                end
            end
        end
        -- Shear is linear on each full-UDL span: its absolute envelope peaks at an end.
        for _,x in ipairs{0,L} do
            local values={}
            for j,base in ipairs(bases) do values[j]=Core.at(base,i,x,x==0 and 'right' or 'left').V end
            for _,maximum in ipairs{true,false} do
                local v,name,gamma=choose(values,maximum)
                out.shear=update(out.shear,record(math.abs(v),x,offsets[i],name,gamma),true)
            end
        end
    end
    for node=1,n+1 do
        local i=node==1 and 1 or node-1
        local x=node==1 and 0 or p.spans[i]
        local M,R={},{}
        for j,base in ipairs(bases) do
            M[j]=moment(Core.at(base,i,x,x==0 and 'right' or 'left').M,x,i)
            R[j]=base.reactions[node].Ry
        end
        for _,field in ipairs{{'M',M},{'R',R}} do
            for _,maximum in ipairs{true,false} do
                local value,name,gamma=choose(field[2],maximum)
                out.supports[node][field[1]..(maximum and 'max' or 'min')]=record(value,0,offsets[node],name,gamma)
            end
        end
    end
    -- Characteristic deflection: two alternating patterns, a verified rule,
    -- not a theorem. The exhaustive comparison belongs only to the test harness.
    for parity=1,2 do
        local factors,names={1},{}
        for i=1,n do
            local active=i%2==parity%2
            factors[i+1]=active and 1 or 0
            if active then names[#names+1]=tostring(i) end
        end
        local name=table.concat(names,'-')
        local characteristic_result,message=Core.combine(bases,factors)
        if not characteristic_result then return nil,message end
        for i,L in ipairs(p.spans) do
            local lo,xlo,hi,xhi=Core.deflection_extrema(characteristic_result,i)
            xlo=math.max(0,math.min(L,xlo));xhi=math.max(0,math.min(L,xhi))
            if xlo==0 or xlo==L then lo=0 end
            if xhi==0 or xhi==L then hi=0 end
            local d=out.spans[i].deflection
            d.down=update(d.down,record(math.max(0,convert(lo)),xlo,offsets[i],name),true)
            d.up=update(d.up,record(math.min(0,convert(hi)),xhi,offsets[i],name),false)
        end
    end
    local Mmax,Mmin,Rmax,Wmax,Xw=-math.huge,math.huge,-math.huge,0,0
    for i,span in ipairs(out.spans) do
        if span.Mmax.value>0 then span.Mplus=span.Mmax end
        local d=span.deflection
        d.governing=d.down.absolute>=d.up.absolute and d.down or d.up
        d.ratio=d.governing.absolute>0 and span.length/d.governing.absolute or nil
        d.utilization={L250=d.governing.absolute/(span.length/250),L300=d.governing.absolute/(span.length/300)}
        d.selected_limit=p.limit
        d.status=not d.ratio and 'N/A' or (d.governing.absolute/(span.length/p.limit)<=1+1e-12 and 'OK' or 'EXCEEDED')
        Mmax=math.max(Mmax,span.Mmax.value);Mmin=math.min(Mmin,span.Mmin.value)
        if d.governing.absolute>Wmax then Wmax=d.governing.absolute;Xw=d.governing.position end
    end
    for _,s in ipairs(out.supports) do Mmin=math.min(Mmin,s.Mmin.value);Rmax=math.max(Rmax,s.Rmax.value) end
    out.summary={moment_max=Mmax,moment_min=Mmin,shear_absolute_max=out.shear.value,reaction_max=Rmax,
        deflection_absolute_max=Wmax,deflection_position=Xw,rigidity=p.EI,span_count=n}
    function out.envelope_at(x,side)
        if not finite(x) or (side~=nil and side~='left' and side~='right') then error('invalid envelope query',0) end
        x=math.max(0,math.min(offsets[n+1],x))
        local i=1
        while i<n and (x>offsets[i+1] or (x==offsets[i+1] and side=='right')) do i=i+1 end
        local s=x-offsets[i]
        local limit=side or (x==0 and 'right' or 'left')
        local moments,shears={},{}
        for j,base in ipairs(bases) do
            local v=Core.at(base,i,s,limit)
            moments[j]=moment(v.M,s,i);shears[j]=v.V
        end
        local values={Mmax=choose(moments,true),Mmin=choose(moments,false),
            Vmax=choose(shears,true),Vmin=choose(shears,false)}
        return values
    end
    return out
end
function ContinuousPreset.solve(p)
    return solve(p)
end


-- Rectangular one-bay portal on Frame, calculation only (P6A).
-- m, kN, kNm; EIc/EIb in kN*m^2. q/P DOWN; H/w global RIGHT.
-- EA=1e6*EI/L^2 approximates negligible axial deformation for THIS preset.
-- The six analytical witnesses differ by order 1e-5, not a universal bound.
-- Frame signs: N tension positive, V=dM/ds, deflection local +y.
-- M>0 tensions local -y: global RIGHT for columns 1 (1->2) and 3 (4->3),
-- global DOWN for beam 2 (2->3). Both columns run from base to top.
PortalPreset={}
local Core=assert(Frame,'load Frame before portal_preset.lua')
local function finite(x) return type(x)=='number' and x==x and math.abs(x)<math.huge end
local function convert(value) return -value end -- sole sign boundary; units stay m/kN

function PortalPreset.model(p)
    if type(p)~='table' then return nil,'expected portal parameters' end
    for _,key in ipairs{'h','l','EIc','EIb'} do
        if not finite(p[key]) or p[key]<=0 then return nil,'invalid '..key end
    end
    if p.base~='PIN' and p.base~='FIX' then return nil,'invalid base' end
    for _,key in ipairs{'q','P','a','H','w'} do
        if not finite(p[key]) then return nil,'invalid '..key end
    end
    if p.a<0 or p.a>p.l then return nil,'a outside beam' end
    local loads={{member=1,type='udl',q=convert(p.w)},
                 {member=2,type='udl',q=convert(p.q)}}
    if p.P~=0 then loads[#loads+1]={member=2,type='point',a=p.a,P=convert(p.P)} end
    return {nodes={{x=0,y=0},{x=0,y=p.h},{x=p.l,y=p.h},{x=p.l,y=0}},
        members={{i=1,j=2,EI=p.EIc,EA=1e6*p.EIc/p.h^2},
                 {i=2,j=3,EI=p.EIb,EA=1e6*p.EIb/p.l^2},
                 {i=4,j=3,EI=p.EIc,EA=1e6*p.EIc/p.h^2}},
        supports={{node=1,ux=true,uy=true,rz=p.base=='FIX'},
                  {node=4,ux=true,uy=true,rz=p.base=='FIX'}},
        nodal_loads={{node=2,Fx=p.H}},member_loads=loads}
end

function PortalPreset.at(sol,member,s,side)
    return Core.at(sol.frame,member,s,side or (s==0 and 'right' or 'left'))
end

-- Roots of a+b*t+c*t^2, in normalized interval coordinates.
local function roots(a,b,c)
    local scale=math.max(math.abs(a),math.abs(b),math.abs(c))
    if scale==0 then return {} end
    a,b,c=a/scale,b/scale,c/scale
    if c==0 then return b==0 and {} or {-a/b} end
    local d=b*b-4*a*c
    if d<0 then return {} end
    local q=-.5*(b+(b<0 and -1 or 1)*math.sqrt(d))
    if q==0 then return {-b/(2*c)} end
    return {q/c,a/q}
end

-- w_rel=w-(1-s/l)*w(0)-(s/l)*w(l). Its stationary equation is
-- theta(s)=chord slope, a cubic on each q/P interval. Split at M=0 so
-- that theta-chord is monotone; bisection then finds ALL sign-changing
-- roots, and split boundaries also cover repeated roots. No grid search.
function PortalPreset.deflection_extrema(sol)
    local p=sol.parameters
    local L=p.l
    local w0=PortalPreset.at(sol,2,0).w
    local wL=PortalPreset.at(sol,2,L).w
    local chord=(wL-w0)/L
    local best={value=0,absolute=0,position=0}
    local function candidate(s)
        local value=PortalPreset.at(sol,2,s).w-(1-s/L)*w0-(s/L)*wL
        if s==0 or s==L then value=0 end
        if math.abs(value)>best.absolute then
            best={value=value,absolute=math.abs(value),position=s}
        end
    end
    local cuts={0,L}
    if p.P~=0 and p.a>0 and p.a<L then cuts={0,p.a,L} end
    local theta=sol.frame.u[6]
    for i=1,#cuts-1 do
        local start,finish=cuts[i],cuts[i+1]
        local d=finish-start
        local v=PortalPreset.at(sol,2,start,'right')
        local q=convert(p.q)
        local function slope(t)
            local x=t*d
            return theta-chord+x*(v.M+x*(v.V/2+x*q/6))/p.EIb
        end
        local split={0,1}
        for _,t in ipairs(roots(v.M,v.V*d,q*d*d/2)) do
            if t>0 and t<1 then split[#split+1]=t end
        end
        table.sort(split)
        for j=1,#split-1 do
            local a,b=split[j],split[j+1]
            candidate(start+a*d);candidate(start+b*d)
            local fa,fb=slope(a),slope(b)
            if (fa<0 and fb>0) or (fa>0 and fb<0) then
                for _=1,60 do
                    local mid=(a+b)/2
                    local fm=slope(mid)
                    if (fa<0 and fm<0) or (fa>0 and fm>0) then a=mid;fa=fm
                    else b=mid end
                end
                candidate(start+(a+b)*d/2)
            end
        end
        theta=theta+d*(v.M+d*(v.V/2+d*q/6))/p.EIb
    end
    return best
end

function PortalPreset.summary(sol)
    return {reactions=sol.reactions,member_extrema=sol.members,
        corner_moments=sol.corners,drift=sol.drift,beam_deflection=sol.deflection}
end

function PortalPreset.solve(p)
    local model,err=PortalPreset.model(p)
    if not model then return nil,err end
    local frame
    frame,err=Core.solve(model) -- exactly one solve, simultaneous characteristic loads
    if not frame then return nil,err end
    local sol={parameters={},frame=frame,members={},reactions={}}
    for _,key in ipairs{'h','l','base','EIc','EIb','q','P','a','H','w'} do sol.parameters[key]=p[key] end
    for _,base in ipairs{{'left',1},{'right',4}} do
        local r=frame.reactions[base[2]]
        sol.reactions[base[1]]={H=r.Rx,V=r.Ry,M=p.base=='FIX' and r.Mz or nil}
    end
    for member=1,3 do
        local lo,xlo,hi,xhi=Core.moment_extrema(frame,member)
        local L=member==2 and p.l or p.h
        local function position(x) return math.max(0,math.min(L,x)) end
        local N=PortalPreset.at(sol,member,0).N -- constant: no axial member loads
        sol.members[member]={moments={minimum={value=lo,position=position(xlo)},
            maximum={value=hi,position=position(xhi)}},
            axial={value=N,absolute=math.abs(N),position=0}}
    end
    sol.corners={left={column=PortalPreset.at(sol,1,p.h).M,beam=PortalPreset.at(sol,2,0).M},
        right={column=PortalPreset.at(sol,3,p.h).M,beam=PortalPreset.at(sol,2,p.l).M}}
    sol.drift={left=frame.u[4],right=frame.u[7]}
    sol.deflection=PortalPreset.deflection_extrema(sol)
    function sol.at(member,s,side) return PortalPreset.at(sol,member,s,side) end
    sol.summary=PortalPreset.summary(sol)
    return sol
end


-- BeamCX v0.6.0, UI (TI-Lua 5.1). Single productive Frame engine.
local SectionDB=DB -- the offline DB from the generated single-file script
local presets={'PIN-PIN','FIX-FREE','FIX-FIX','FIX-PIN','CONTINUOUS','PORTAL'}
local params={L=6,q=10,P=0,a=3,EI=10000,support=1}
local section={material=1,profile=6,b=250,h=450,manualEI=10000}
local settings={self_weight=false,limit=250}
local names={'support','L','q','P','a','EI'}
local units={'','m','kN/m','kN','m','kN*m2'}
local page=0 -- 0 system selector, 1 beam input, 2 diagram, 3 sections
local sel_index=params.support -- temporary focus; params.support is authoritative
local selector_error=nil
local restore_notice=nil
local mode=1 -- 1 M, 2 V, 3 w, 4 compact results (inside page 2)
local edit_index,sec_index=1,1
local typing=nil
local cursor=0.5
local result,err=nil,nil
local summary,export_message=nil,nil
local q_sw=nil -- available section self-weight; params.q always remains q_user

local continuous={spans={6,6,6},left='PIN',right='PIN',g=10,q=5,
    gG_sup=1.35,gG_inf=1,gQ=1.5}
local portal={h=4,l=6,base='FIX',EIc=10000,EIb=15000,q=10,P=0,a=3,H=0,w=0}
local portal_fields={{'base','Base'},{'h','Height h [m]'},{'l','Width l [m]'},
    {'EIc','EI columns [kNm2]'},{'EIb','EI beam [kNm2]'},{'q','Beam q [kN/m]'},
    {'P','Beam P [kN]'},{'a','Position a [m]'},{'H','Nodal H [kN]'},{'w','Wind w [kN/m]'}}
local portal_member,portal_s,portal_side=2,3,'left'
local portal_confirmed=nil
local samples,cursor_value,characteristic=nil,nil,nil
local stale,calculating=true,false
local table_page,edit_top,sec_top=1,1,1
local selection_before=nil -- retained until the first deferred solve succeeds
local function finite(v) return type(v)=='number' and v==v and math.abs(v)<math.huge end
local function copy(t)
    local out={}
    for k,v in pairs(t) do out[k]=type(v)=='table' and copy(v) or v end
    return out
end
local default_params,default_section,default_continuous=copy(params),copy(section),copy(continuous)
local default_portal=copy(portal)
local function continuous_parameters()
    local p=copy(continuous)
    p.EI=params.EI;p.limit=settings.limit
    p.g=p.g+(settings.self_weight and q_sw or 0)
    return p
end
local function continuous_rows()
    local rows={{key='n',caption='Spans',value=#continuous.spans}}
    for i,L in ipairs(continuous.spans) do
        rows[#rows+1]={key=i,caption='L'..i..' [m]',value=L}
    end
    for _,r in ipairs{{'left','Left end'},{'right','Right end'},
        {'g','g [kN/m]'},{'q','q [kN/m]'}, {'gG_sup','γG,sup'},
        {'gG_inf','γG,inf'},{'gQ','γQ'}} do
        rows[#rows+1]={key=r[1],caption=r[2],value=continuous[r[1]]}
    end
    return rows
end
local function dirty()
    stale=true;calculating=false;samples=nil;cursor_value=nil;characteristic=nil
    result=nil;summary=nil;export_message=nil;err=nil
end
local function dirty_portal()
    stale=true;calculating=false;samples=nil;cursor_value=nil;export_message=nil;err=nil
end

local function fmt(x)
    if x==nil then return '--' end
    if x==0 then return '0.00' end -- also normalize IEEE negative zero
    if math.abs(x)<0.005 or math.abs(x)>=1e7 then return string.format('%.2e',x) end
    return string.format('%.2f',x)
end
local function sec_info() return SectionDB.compute(section) end
local function lref_factor()
    local material=SectionDB.materials[section.material]
    if params.support==2 and material and material.kind=='concrete' then
        -- DIN EN 1992-1-1/NA 7.4.1: cantilever span = 2.5 x cantilever length
        return 2.5
    end
    return 1
end
local function recalc()
    if params.support==6 then dirty_portal();return true end
    if params.support==5 then
        local info,message=sec_info()
        if not info then err=message;return false end
        params.EI=info.EI;q_sw=info.q_sw
        if q_sw==nil then settings.self_weight=false end
        dirty();return true
    end
    result=nil;summary=nil;export_message=nil
    local info,message=sec_info()
    if not info then result=nil;err=message;page=3;return end
    params.EI=info.EI
    q_sw=info.q_sw
    -- Manual EI / missing catalogue weight never substitutes an invented load.
    if q_sw==nil then settings.self_weight=false end
    local p={}
    for k,v in pairs(params) do p[k]=v end
    p.q=params.q+(settings.self_weight and q_sw or 0)
    result,err=BeamPreset.solve(p,settings.limit,lref_factor())
    if result then summary=result.summary end
    if not result then page=1 end
    return result~=nil
end
recalc()

-- Only the timer invokes this calculation and creates the drawing cache.
local function deflections_at(x)
    local i=1
    while i<#result.spans and x>result.supports[i+1].position do i=i+1 end
    local local_x=x-result.spans[i].offset
    return -Frame.at(characteristic[1],i,local_x).w*1000,
        -Frame.at(characteristic[2],i,local_x).w*1000
end
local function cache_cursor()
    if not result or not samples then return end
    if params.support==6 then
        local L=portal_member==2 and portal.l or portal.h
        portal_s=math.max(0,math.min(L,portal_s))
        if portal_s==0 then portal_side='right' elseif portal_s==L then portal_side='left' end
        cursor_value=PortalPreset.at(result,portal_member,portal_s,portal_side)
        return
    end
    local total=result.supports[#result.supports].position
    local x=cursor*total
    for _,s in ipairs(result.supports) do
        if math.abs(s.position-x)<1e-9*math.max(1,total) then x=s.position;break end
    end
    cursor_value=result.envelope_at(x) -- exactly one envelope query per movement
    cursor_value.x=x
    cursor_value.wodd,cursor_value.weven=deflections_at(x)
    for i,s in ipairs(result.supports) do
        if s.position==x and i>1 and i<#result.supports then
            cursor_value.left=samples.supports[i].left
            cursor_value.right=samples.supports[i].right
        end
    end
end
local function cache_portal()
    samples={members={},scales={M=0,V=0,N=0},vabs={},table={}}
    local max_displacement=0
    for member=1,3 do
        local L=member==2 and portal.l or portal.h
        local positions={0,L}
        for j=1,19 do positions[#positions+1]=L*j/20 end
        if member==2 and portal.P~=0 and portal.a>0 and portal.a<L then positions[#positions+1]=portal.a end
        table.sort(positions)
        local data={};samples.members[member]=data
        local last=nil
        for _,s in ipairs(positions) do
            if s~=last then
                local sides={s==0 and 'right' or 'left'}
                if member==2 and portal.P~=0 and s==portal.a and s>0 and s<L then sides={'left','right'} end
                for _,side in ipairs(sides) do
                    local v=PortalPreset.at(result,member,s,side)
                    v.s=s;v.side=side
                    -- Local x bottom->top on BOTH columns; beam left->right.
                    if member==2 then v.x=s;v.y=portal.h;v.dx=v.u;v.dy=v.w
                    else v.x=member==1 and 0 or portal.l;v.y=s;v.dx=-v.w;v.dy=v.u end
                    max_displacement=math.max(max_displacement,math.abs(v.dx),math.abs(v.dy))
                    data[#data+1]=v
                end
            end
            last=s
        end
        -- V is linear between the endpoint/P cuts in this preset. These
        -- exact cuts determine |V|max, independently of screen sampling.
        local cuts={{0,'right'},{L,'left'}}
        if member==2 and portal.P~=0 and portal.a>0 and portal.a<L then
            cuts[#cuts+1]={portal.a,'left'};cuts[#cuts+1]={portal.a,'right'}
        end
        local vabs=0
        for _,cut in ipairs(cuts) do vabs=math.max(vabs,math.abs(PortalPreset.at(result,member,cut[1],cut[2]).V)) end
        samples.vabs[member]=vabs;samples.scales.V=math.max(samples.scales.V,vabs)
        local m=result.members[member]
        samples.scales.M=math.max(samples.scales.M,math.abs(m.moments.minimum.value),math.abs(m.moments.maximum.value))
        samples.scales.N=math.max(samples.scales.N,m.axial.absolute)
    end
    samples.magnification=max_displacement>0 and .12*math.max(portal.h,portal.l)/max_displacement or 1
    local function row(caption,value) samples.table[#samples.table+1]={caption,value} end
    for _,side in ipairs{'left','right'} do
        local r=result.reactions[side]
        row(side..' base H [kN]',fmt(r.H));row(side..' base V [kN]',fmt(r.V))
        row(side..' base M [kNm]',r.M and fmt(r.M) or '—')
    end
    for i,m in ipairs(result.members) do
        row('Member '..i..' N [kN]',fmt(m.axial.value))
        row('M'..i..' min [kNm]',fmt(m.moments.minimum.value)..' @ '..fmt(m.moments.minimum.position)..' m')
        row('M'..i..' max [kNm]',fmt(m.moments.maximum.value)..' @ '..fmt(m.moments.maximum.position)..' m')
        row('Member '..i..' |V|max [kN]',fmt(samples.vabs[i]))
    end
    for _,side in ipairs{'left','right'} do
        row(side..' corner col [kNm]',fmt(result.corners[side].column))
        row(side..' corner beam [kNm]',fmt(result.corners[side].beam))
    end
    for _,side in ipairs{'left','right'} do
        local drift=result.drift[side]
        row(side..' drift [mm]',fmt(drift*1000))
        row(side..' h/|drift|',drift~=0 and fmt(portal.h/math.abs(drift)) or '—')
    end
    row('Beam w_rel [mm]',fmt(result.deflection.value*1000))
    row('Beam l/|w_rel|',result.deflection.absolute>0 and fmt(portal.l/result.deflection.absolute) or '—')
    row('w_rel position [m]',fmt(result.deflection.position))
    cache_cursor()
end
local function cache_samples()
    characteristic={}
    for parity=1,2 do
        local factors={1}
        for i=1,#continuous.spans do factors[i+1]=i%2==parity%2 and 1 or 0 end
        characteristic[parity]=assert(Frame.combine(result.bases,factors))
    end
    samples={supports={}}
    for i,span in ipairs(result.spans) do
        for j=0,20 do
            local x=span.offset+span.length*j/20
            local side=j==20 and 'left' or 'right'
            local v=result.envelope_at(x,side)
            v.x=x;v.wodd,v.weven=deflections_at(x)
            samples[#samples+1]=v
            if j==0 then
                samples.supports[i]=samples.supports[i] or {}
                samples.supports[i].right=v
            elseif j==20 then samples.supports[i+1]={left=v} end
        end
    end
    cache_cursor()
end
local function rollback_selection(message)
    if selection_before then
        local b=selection_before
        params=b.params;section=b.section;settings=b.settings
        result=b.result;summary=b.summary;err=b.err;export_message=b.export_message
        q_sw=b.q_sw;samples=b.samples;cursor_value=b.cursor_value;characteristic=b.characteristic
        stale=b.stale;continuous=b.continuous;portal=b.portal
        portal_confirmed=b.portal_confirmed
        mode=b.mode;table_page=b.table_page;edit_index=b.edit_index;edit_top=b.edit_top
        portal_member=b.portal_member;portal_s=b.portal_s;portal_side=b.portal_side
        page=0;selector_error=message;selection_before=nil
    else err=message;page=1 end
end
local function open_selected_system()
    local before={params=copy(params),section=copy(section),settings=copy(settings),
        result=result,summary=summary,err=err,export_message=export_message,q_sw=q_sw,
        samples=samples,cursor_value=cursor_value,characteristic=characteristic,
        stale=stale,continuous=copy(continuous),portal=copy(portal),portal_confirmed=portal_confirmed,
        mode=mode,table_page=table_page,edit_index=edit_index,edit_top=edit_top,
        portal_member=portal_member,portal_s=portal_s,portal_side=portal_side}
    params.support=sel_index
    if sel_index~=6 then mode=math.min(mode,4) end
    if sel_index==6 then
        selection_before=before.params.support~=6 and before or nil
        selector_error=nil;page=1;edit_index=1;edit_top=1;mode=1;table_page=1
        if before.params.support~=6 then dirty_portal() end
    elseif sel_index==5 then
        selection_before=before
        if recalc() then selector_error=nil;page=1;edit_index=1;edit_top=1
        else rollback_selection(err) end
    else
        recalc()
        if result~=nil then selector_error=nil;page=1;selection_before=nil;edit_index=1
        else
            selection_before=before
            rollback_selection(err or 'calculation failed')
        end
    end
end
local function show_results()
    page=2
    if params.support==6 and not stale then err=nil end
    if (params.support==5 or params.support==6) and stale then
        calculating=true
        platform.window:invalidate()
        timer.start(0.05)
    end
end

local function export_cas()
    export_message=nil
    if not result or not summary or err or (params.support==6 and stale) then
        export_message='CAS BLOCKED: solve first';return
    end
    if not var or type(var.store)~='function' then
        export_message='CAS ERROR: API unavailable';return
    end
    local values={
        {'bx_mmax',summary.bx_mmax},{'bx_mmin',summary.bx_mmin},
        {'bx_vabs',summary.bx_vabs},{'bx_wmax',summary.bx_wmax},
        {'bx_xwmax',summary.bx_xwmax},{'bx_ra',summary.bx_ra},
        {'bx_rb',summary.bx_rb},{'bx_ei',summary.bx_ei}
    }
    if params.support==5 then
        values={{'bc_mmax',summary.moment_max},{'bc_mmin',summary.moment_min},
            {'bc_vabs',summary.shear_absolute_max},{'bc_rmax',summary.reaction_max},
            {'bc_wmax',summary.deflection_absolute_max*1000},
            {'bc_xwmax',summary.deflection_position},{'bc_ei',summary.rigidity},
            {'bc_n',summary.span_count}}
    elseif params.support==6 then
        local r=result.reactions
        local mmax,mmin=-math.huge,math.huge
        for _,m in ipairs(result.members) do
            mmax=math.max(mmax,m.moments.maximum.value);mmin=math.min(mmin,m.moments.minimum.value)
        end
        values={{'bp_hl',r.left.H},{'bp_vl',r.left.V},{'bp_ml',r.left.M or 0},
            {'bp_hr',r.right.H},{'bp_vr',r.right.V},{'bp_mr',r.right.M or 0},
            {'bp_mmax',mmax},{'bp_mmin',mmin},{'bp_nabs',samples.scales.N},{'bp_vabs',samples.scales.V},
            {'bp_dxl',result.drift.left*1000},{'bp_dxr',result.drift.right*1000},
            {'bp_wrel',result.deflection.value*1000},{'bp_xwrel',result.deflection.position}}
    end
    for _,v in ipairs(values) do
        if type(v[2])~='number' or v[2]~=v[2] or math.abs(v[2])==math.huge then
            export_message='CAS ERROR: invalid '..v[1];return
        end
    end
    for _,v in ipairs(values) do
        -- Native var.store returns nil on success, an error message on failure.
        local ok,message=pcall(var.store,v[1],v[2])
        if not ok or message~=nil then
            export_message='CAS ERROR '..v[1]..': '..string.sub(tostring(message),1,18)
            return -- Earlier stores may have succeeded; never report full success.
        end
    end
    export_message='CAS: '..#values..' variables stored'
end

local function color(gc,r,g,b) gc:setColorRGB(r,g,b) end
local function label(gc,t,x,y) gc:drawString(t,x,y,'top') end
local function fitted(gc,t,x,y,width,size)
    size=size or 9
    gc:setFont('sansserif','r',size)
    local fitted_size=size
    local text_width=gc.getStringWidth and gc:getStringWidth(t)
    while type(text_width)=='number' and text_width>width and fitted_size>6 do
        fitted_size=fitted_size-1
        gc:setFont('sansserif','r',fitted_size)
        text_width=gc:getStringWidth(t)
    end
    label(gc,t,x,y)
    gc:setFont('sansserif','r',size)
end
local function selector_message(gc,text,w,h)
    -- Use the reserved footer area without dropping diagnostic text.
    local lines,size={},9
    repeat
        gc:setFont('sansserif','r',size)
        lines={''}
        for word in string.gmatch(text,'%S+') do
            local i=#lines
            local candidate=lines[i]=='' and word or lines[i]..' '..word
            if gc:getStringWidth(candidate)>w-16 and lines[i]~='' then
                lines[i+1]=word
            else lines[i]=candidate end
        end
        if #lines*(size+3)<=27 or size==6 then break end
        size=size-1
    until false
    for i,line in ipairs(lines) do label(gc,line,8,h-42+(i-1)*(size+3)) end
    gc:setFont('sansserif','r',9)
end
local function header(gc,w)
    color(gc,18,44,66);gc:fillRect(0,0,w,22)
    color(gc,255,255,255);gc:setFont('sansserif','b',11)
    label(gc,'BeamCX | EB 2D | v0.6.0',6,4)
end
local function name_value(index)
    local key=names[index]
    if key=='support' then return presets[params.support] end
    return fmt(params[key])
end
local function draw_edit(gc,w,h)
    color(gc,215,225,236);gc:setFont('sansserif','r',10)
    label(gc,'BEAM INPUT  (downward loads +)',8,29)
    for i=1,#names do
        local y=46+(i-1)*21
        if i==edit_index then
            color(gc,213,232,245);gc:fillRect(6,y-1,w-12,21)
            color(gc,18,44,66)
        else color(gc,215,225,236) end
        local key=names[i]
        label(gc,key=='support' and 'Supports' or (key=='q' and 'q user' or key),14,y+2)
        local text=(i==edit_index and typing~=nil) and (typing..'_') or name_value(i)
        if i==6 and section.material~=1 then
            text=text..' (auto)'
        end
        fitted(gc,text,100,y+2,w-184,10)
        gc:setFont('sansserif','r',10)
        if units[i]~='' then label(gc,units[i],w-78,y+2) end
    end
    if err then
        color(gc,255,140,120);label(gc,err,7,h-46)
    elseif result then
        color(gc,128,222,181)
        local lo,hi=result.moments.minimum.value,result.moments.maximum.value
        label(gc,'Mmin='..fmt(lo)..'  Mmax='..fmt(hi)..' kNm',7,h-46)
    end
    color(gc,171,193,207);gc:setFont('sansserif','r',9)
    label(gc,'UP/DOWN field  |  ENTER apply',7,h-31)
    label(gc,'TAB plot; TAB again = sections',7,h-19)
end

local function scroll_top(index,top,count)
    if index<top then return index end
    if index>=top+count then return index-count+1 end
    return top
end
local function draw_continuous_edit(gc,w,h)
    color(gc,215,225,236);gc:setFont('sansserif','r',10)
    label(gc,'CONTINUOUS | Input',8,28)
    local rows=continuous_rows()
    local count=math.max(1,math.floor((h-94)/18))
    edit_top=scroll_top(edit_index,edit_top,count)
    for i=edit_top,math.min(#rows,edit_top+count-1) do
        local row=rows[i]
        local y=46+(i-edit_top)*18
        if i==edit_index then
            color(gc,213,232,245);gc:fillRect(6,y-1,w-12,18)
            color(gc,18,44,66)
        else color(gc,215,225,236) end
        label(gc,row.caption,12,y)
        local value=type(row.value)=='number' and fmt(row.value) or row.value
        fitted(gc,i==edit_index and typing~=nil and typing..'_' or value,160,y,w-174,10)
    end
    gc:setFont('sansserif','r',9);color(gc,255,200,112)
    fitted(gc,err or (stale and 'Outdated | TAB: calculate' or 'Result saved'),7,h-45,w-14)
    color(gc,171,193,207)
    label(gc,'UP/DOWN field | LEFT/RIGHT spans, ends',7,h-30)
    label(gc,'ENTER apply | TAB results',7,h-16)
end

local function section_rows()
    local m=SectionDB.materials[section.material]
    local info=sec_info()
    local rows={{key='material',caption='Material',value=m.name,editable=true}}
    if m.kind=='manual' then
        rows[#rows+1]={key='manualEI',caption='EI [kNm2]',value=fmt(section.manualEI),editable=true}
    elseif m.kind=='concrete' then
        rows[#rows+1]={key='shape',caption='Section',value='RECT',editable=false}
        rows[#rows+1]={key='b',caption='b [mm]',value=fmt(section.b),editable=true}
        rows[#rows+1]={key='h',caption='h [mm]',value=fmt(section.h),editable=true}
        rows[#rows+1]={key='E',caption='E [GPa]',value=fmt(m.E/1000),editable=false}
        rows[#rows+1]={key='I',caption='I [cm4]',value=info and fmt(info.I*1e8) or '--',editable=false}
        rows[#rows+1]={key='EI',caption='EI [kNm2]',value=info and fmt(info.EI) or '--',editable=false}
    else
        rows[#rows+1]={key='profile',caption='Profile',value=SectionDB.profiles[section.profile][1],editable=true}
        rows[#rows+1]={key='E',caption='E [GPa]',value=fmt(m.E/1000),editable=false}
        rows[#rows+1]={key='I',caption='Iy [cm4]',value=info and fmt(info.I*1e8) or '--',editable=false}
        rows[#rows+1]={key='EI',caption='EI [kNm2]',value=info and fmt(info.EI) or '--',editable=false}
    end
    rows[#rows+1]={key='self_weight',caption='Self-weight',
        value=info and info.q_sw and (settings.self_weight and 'ON' or 'OFF') or 'N/A',editable=true}
    if params.support==5 then
        rows[#rows+1]={key='limit',caption='Defl. limit',value='L/'..settings.limit,editable=true}
    end
    return rows
end
local function active_section_index()
    local rows=section_rows()
    if not rows[sec_index] or not rows[sec_index].editable then sec_index=1 end
    return rows
end
local function draw_section(gc,w,h)
    color(gc,215,225,236);gc:setFont('sansserif','r',10)
    label(gc,'OFFLINE MATERIAL / SECTION',8,29)
    local rows=active_section_index()
    local count=params.support==5 and math.max(1,math.floor((h-82)/17)) or #rows
    sec_top=params.support==5 and scroll_top(sec_index,sec_top,count) or 1
    for i=sec_top,math.min(#rows,sec_top+count-1) do
        local row=rows[i]
        local y=45+(i-sec_top)*17
        if i==sec_index then
            color(gc,213,232,245);gc:fillRect(6,y-1,w-12,17)
            color(gc,18,44,66)
        elseif row.editable then color(gc,215,225,236)
        else color(gc,129,164,181) end
        label(gc,row.caption,14,y+2)
        fitted(gc,(i==sec_index and typing~=nil) and (typing..'_') or row.value,122,y+2,w-130,10)
    end
    if err then color(gc,255,140,120);label(gc,err,7,h-31) end
    color(gc,171,193,207);gc:setFont('sansserif','r',9)
    if not err then label(gc,'UP/DOWN field  |  LEFT/RIGHT select',7,h-31) end
    label(gc,'Type dimensions  |  TAB input',7,h-19)
end

local function draw_results(gc,w,h)
    color(gc,215,225,236);gc:setFont('sansserif','r',10)
    local s=result.deflection_check
    local cas=result.summary
    label(gc,'QUICK CHECK | deflection comparison',7,27)
    label(gc,'|w|max='..fmt(cas.bx_wmax)..' mm',7,46)
    label(gc,'x='..fmt(cas.bx_xwmax)..' m',193,46)
    local ratio_label=s.lref_factor==2.5 and 'Lref/|w|=' or 'L/|w|='
    label(gc,ratio_label..(s.span_deflection_ratio and fmt(s.span_deflection_ratio) or 'N/A'),7,64)
    label(gc,'L/'..settings.limit..': '..s.status,163,64)
    label(gc,'L/250: '..fmt(s.utilization.L250*100)..'%',7,82)
    label(gc,'L/300: '..fmt(s.utilization.L300*100)..'%',163,82)
    label(gc,'SW '..(q_sw and (settings.self_weight and 'ON' or 'OFF') or 'N/A')..
        ' | q sw='..(q_sw and fmt(q_sw) or 'N/A')..' kN/m',7,100)
    label(gc,'q total='..fmt(result.parameters.q)..' kN/m',7,118)
    if result.parameters.support==2 then
        gc:setFont('sansserif','r',9);color(gc,255,200,112)
        if s.lref_factor==2.5 then
            label(gc,'Lref=2.5L (EC2/NA)',7,136)
            label(gc,'RC: GROSS EI ONLY',168,136)
        else label(gc,'CANTILEVER: AGREE LIMIT',7,136) end
        gc:setFont('sansserif','r',10)
    elseif sec_info().kind=='concrete' then
        color(gc,255,200,112);label(gc,'RC: GROSS EI ONLY',7,136)
    end
    color(gc,128,222,181);label(gc,'ENTER: EXPORT CAS',7,h-58)
    gc:setFont('sansserif','r',9)
    if export_message then
        color(gc,255,200,112);label(gc,export_message,7,h-39)
    end
    color(gc,171,193,207)
    label(gc,'UP/DOWN L/250 / L/300',7,h-25)
    label(gc,'LEFT/RIGHT plots | TAB sections',7,h-13)
end

local function support(gc,x,y,isleft,clamp)
    color(gc,91,195,203)
    if clamp then
        gc:drawLine(x,y-13,x,y+13)
        for j=0,4 do gc:drawLine(x-5,y-11+j*5,x,y-15+j*5) end
    else
        gc:drawLine(x,y,x-9,y+12);gc:drawLine(x,y,x+9,y+12)
        gc:drawLine(x-10,y+12,x+10,y+12)
        if not isleft then gc:drawLine(x-10,y+16,x+10,y+16) end
    end
end
-- Compact selector-only supports; the diagram support() above is unchanged.
local function mini_support(gc,x,y,isleft,clamp)
    color(gc,91,195,203)
    if clamp then
        gc:drawLine(x,y-5,x,y+5)
        for j=0,4 do gc:drawLine(x-3,y-3+j*2,x,y-5+j*2) end
    else
        gc:drawLine(x,y,x-5,y+6);gc:drawLine(x,y,x+5,y+6)
        gc:drawLine(x-5,y+6,x+5,y+6)
        if not isleft then gc:drawLine(x-5,y+9,x+5,y+9) end
    end
end
-- Reference UDL moments / (q*L^2), independent of the current model.
local selector_moment_ends={{0,0},{-1/2,0},{-1/12,-1/12},{-1/8,0}}
local function selector_moment(index,xi)
    if index==5 then
        local i=math.min(3,math.floor(xi*3)+1)
        local t=xi*3-(i-1)
        local ends={0,-.1,-.1,0}
        return t*(1-t)/2+ends[i]*(1-t)+ends[i+1]*t
    end
    local ends=selector_moment_ends[index]
    return xi*(1-xi)/2+ends[1]*(1-xi)+ends[2]*xi
end
local function draw_selector(gc,w,h)
    color(gc,215,225,236);gc:setFont('sansserif','r',10)
    label(gc,'SELECT SYSTEM',8,28)
    gc:setFont('sansserif','r',9)
    label(gc,'M (q>0)',w-76,28)
    local margin,gap,top=8,8,46
    local card_w=(w-2*margin-2*gap)/3
    local card_h=(h-43-top-gap)/2
    gc:setPen('thin','smooth')
    for i=1,6 do
        local x=margin+((i-1)%3)*(card_w+gap)
        local y=top+math.floor((i-1)/3)*(card_h+gap)
        if i==sel_index then color(gc,213,232,245)
        else color(gc,23,46,62) end
        gc:fillRect(x,y,card_w,card_h)
        if i==sel_index then color(gc,18,44,66)
        else color(gc,215,225,236) end
        -- Zones: name [y+2,y+14], schematic [y+15,y+33],
        -- moment [y+35,y+card_h-2]. The last zone follows the window height.
        gc:setFont('sansserif','r',9)
        if gc:getStringWidth(presets[i])>card_w-8 then gc:setFont('sansserif','r',8) end
        label(gc,presets[i],x+(card_w-gc:getStringWidth(presets[i]))/2,y+2)
        if i==6 then
            local left,right,top,bottom=x+24,x+card_w-24,y+18,y+card_h-8
            gc:drawLine(left,bottom,left,top);gc:drawLine(left,top,right,top);gc:drawLine(right,top,right,bottom)
            color(gc,91,195,203)
            for _,base in ipairs{left,right} do
                gc:drawLine(base-6,bottom,base+6,bottom)
                for k=-1,1 do gc:drawLine(base+k*4,bottom,base+k*4-2,bottom+3) end
            end
            if card_h>=55 then
                -- Illustrative fixed portal under q>0, unrelated to live inputs.
                color(gc,242,177,103)
                gc:drawLine(left+3,bottom,left-6,top)
                gc:drawLine(right-3,bottom,right+6,top)
                for k=0,15 do
                    local a,b=k/16,(k+1)/16
                    gc:drawLine(left+(right-left)*a,top-6+32*a*(1-a),
                        left+(right-left)*b,top-6+32*b*(1-b))
                end
            end
        else
        local left,right,ybeam=x+12,x+card_w-12,y+22
        gc:drawLine(left,ybeam,right,ybeam)
        if i==5 then
            for k=0,3 do mini_support(gc,left+(right-left)*k/3,ybeam,k==0,false) end
        else
            mini_support(gc,left,ybeam,true,i~=1)
            if i~=2 then mini_support(gc,right,ybeam,false,i==3) end
        end
        local moment_top,moment_bottom=y+35,y+card_h-2
        local moment_h=moment_bottom-moment_top
        if moment_h>=14 then
            local mid=(moment_top+moment_bottom)/2
            local data,max_m={},0
            for j=0,32 do
                local m=selector_moment(i,j/32)
                data[j+1]=m;max_m=math.max(max_m,math.abs(m))
            end
            color(gc,115,132,148);gc:drawLine(left,mid,right,mid)
            color(gc,242,177,103) -- same color and thin smooth pen as diagram M
            for j=1,32 do
                local x0=left+(right-left)*(j-1)/32
                local x1=left+(right-left)*j/32
                -- Positive sagging moments are below the reference axis.
                gc:drawLine(x0,mid+data[j]*moment_h/(2*max_m),
                    x1,mid+data[j+1]*moment_h/(2*max_m))
            end
        end
        end -- beam/continuous reference card
    end
    gc:setFont('sansserif','r',9)
    if restore_notice then
        color(gc,255,200,112)
        label(gc,'Invalid document or version:',8,h-42)
        label(gc,'defaults restored',8,h-29)
    elseif selector_error then
        color(gc,255,140,120)
        selector_message(gc,selector_error,w,h)
    end
    color(gc,171,193,207)
    label(gc,'ARROWS select | ENTER open',8,h-15)
end
-- Draw one signed load arrow: shaft stops at the solid triangular head.
-- Pixel-aligned geometry prevents two open V strokes from resembling stacked heads.
local function load_arrow(gc,xc,tail,tip,halfwidth)
    local x=math.floor(xc+0.5)
    local direction=tip>=tail and 1 or -1
    local base=tip-7*direction
    gc:drawLine(x,tail,x,base)
    gc:fillPolygon({x-halfwidth,base,x+halfwidth,base,x,tip})
end
local function diagram(gc,w,h)
    local p=result.parameters
    local left,right=23,w-23
    local info=sec_info()
    color(gc,215,225,236);gc:setFont('sansserif','r',10)
    local section_label=info.kind=='concrete' and 'RECT '..fmt(section.b)..'x'..fmt(section.h) or info.label
    local title=presets[p.support]..'  L='..fmt(p.L)..'m  '..section_label
    label(gc,title,7,29)
    local title_h=gc.getStringHeight and gc:getStringHeight(title)
    -- Without font metrics, use the 10 pt font plus 4 px for its text box.
    if type(title_h)~='number' then title_h=10+4 end
    local title_bottom=29+title_h
    local ybeam=math.ceil(title_bottom+4+26) -- 4 px clearance, 26 px P arrow
    color(gc,216,228,237);gc:setPen('medium','smooth')
    gc:drawLine(left,ybeam,right,ybeam)
    support(gc,left,ybeam,true,p.support~=1)
    if p.support~=2 then support(gc,right,ybeam,false,p.support==3) end
    gc:setPen('thin','smooth')
    if p.q~=0 then
        color(gc,230,179,83)
        local qleft,qright=left+10,right-10
        local qtop=ybeam-18
        gc:drawLine(qleft,qtop,qright,qtop)
        for i=0,8 do
            local xx=qleft+(qright-qleft)*i/8
            load_arrow(gc,xx,p.q>0 and qtop or ybeam,p.q>0 and ybeam or qtop,3)
        end
    end
    if p.P~=0 then
        local xp=left+(right-left)*p.a/p.L
        color(gc,235,100,105)
        load_arrow(gc,xp,p.P>0 and ybeam-26 or ybeam,p.P>0 and ybeam or ybeam-26,4)
    end
    local namesplot={'M [kNm]','V [kN]','w [mm]'}
    color(gc,225,235,246);gc:setPen('thin','smooth')
    local plot_label_y=math.max(91,ybeam+18)
    label(gc,namesplot[mode]..'   LEFT/RIGHT: change',8,plot_label_y)
    local top,bottom=math.max(111,plot_label_y+title_h+2),h-50
    local mid=(top+bottom)/2
    color(gc,115,132,148);gc:drawLine(left,mid,right,mid)
    local data={}
    local min,max=math.huge,-math.huge
    for i=0,100 do
        local x=p.L*i/100
        local v=BeamPreset.at(result,x)
        local ordinate=(mode==1 and v.M) or (mode==2 and v.V) or (v.w*1000)
        data[i+1]=ordinate
        if ordinate<min then min=ordinate end
        if ordinate>max then max=ordinate end
    end
    local scale=math.max(math.abs(min),math.abs(max),1e-10)
    local amp=(bottom-top)*0.42
    color(gc,mode==1 and 242 or 80,mode==2 and 213 or 177,mode==3 and 235 or 103)
    gc:setPen('thin','smooth')
    -- Bending moment: sagging (+) below reference axis, hogging (-) above.
    -- Keep shear and deflection display conventions unchanged.
    local ordinate_sign=(mode==1) and 1 or -1
    for i=1,100 do
        local x0=left+(right-left)*(i-1)/100
        local x1=left+(right-left)*i/100
        gc:drawLine(x0,mid+ordinate_sign*amp*data[i]/scale,x1,mid+ordinate_sign*amp*data[i+1]/scale)
    end
    local xx=left+(right-left)*cursor
    local v=BeamPreset.at(result,p.L*cursor)
    local ordinate=(mode==1 and v.M) or (mode==2 and v.V) or (v.w*1000)
    color(gc,173,198,210);gc:setPen('thin','dotted')
    gc:drawLine(xx,top,xx,bottom)
    color(gc,244,244,244);gc:setFont('sansserif','r',10)
    label(gc,'x='..fmt(cursor*p.L)..' m  '..namesplot[mode]..'='..fmt(ordinate),8,h-42)
    local r=result.reactions
    label(gc,'RA='..fmt(r.left.Ry)..' RB='..fmt(r.right.Ry)..' kN',8,h-29)
    color(gc,171,193,207);gc:setFont('sansserif','r',9)
    label(gc,'UP/DOWN cursor | ENTER results',8,h-15)
end

local function draw_continuous_table(gc,w,h)
    color(gc,215,225,236);gc:setFont('sansserif','r',9)
    label(gc,'CONTINUOUS | '..(table_page==1 and 'Spans' or 'Supports')..' | L/'..settings.limit,7,27)
    gc:setFont('sansserif','r',8)
    if table_page==1 then
        for _,c in ipairs{{'#',7},{'L [m]',27},{'M+ kNm',61},{'w mm',119},{'L/|w|',185},{'Status',253}} do
            label(gc,c[1],c[2],44)
        end
        for i,s in ipairs(result.spans) do
            local y=59+(i-1)*13
            local d=s.deflection
            label(gc,tostring(i),7,y);label(gc,fmt(s.length),27,y)
            label(gc,s.Mplus and fmt(s.Mplus.value) or '—',61,y)
            label(gc,(d.governing.value<0 and '↑' or '↓')..fmt(d.governing.absolute*1000),119,y)
            label(gc,d.ratio and fmt(d.ratio) or 'N/A',185,y)
            label(gc,d.status,253,y)
        end
    else
        for _,c in ipairs{{'#',7},{'Mmin',32},{'Mmax>0',104},{'Rmax',176},{'Rmin',248}} do
            label(gc,c[1],c[2],44)
        end
        for i,s in ipairs(result.supports) do
            local y=59+(i-1)*13
            label(gc,tostring(i),7,y);label(gc,fmt(s.Mmin.value),32,y)
            label(gc,s.Mmax.value>0 and fmt(s.Mmax.value) or '—',104,y)
            label(gc,fmt(s.Rmax.value),176,y);label(gc,fmt(s.Rmin.value),248,y)
        end
    end
    label(gc,'|V|max='..fmt(result.shear.value)..' kN | M kNm, R kN',7,h-69)
    local p=result.parameters
    label(gc,'γG,sup='..fmt(p.gG_sup)..'  γG,inf='..fmt(p.gG_inf)..'  γQ='..fmt(p.gQ),7,h-56)
    label(gc,'γ: OPEN (EN 1990 A1 + NA)',7,h-43)
    color(gc,128,222,181)
    fitted(gc,export_message or 'ENTER: EXPORT CAS bc_*',7,h-29,w-14)
    color(gc,171,193,207)
    label(gc,'UP/DOWN table | LEFT/RIGHT mode | TAB section',7,h-15)
end
local function continuous_diagram(gc,w,h)
    color(gc,215,225,236);gc:setFont('sansserif','r',9)
    local titles={'M envelope [kNm]','V envelope [kN]','w characteristic [mm]'}
    label(gc,'CONTINUOUS | '..titles[mode],7,28)
    label(gc,mode==3 and 'Orange: odd | Blue: even' or 'Orange: max | Blue: min',7,43)
    local left,right=23,w-23
    local total=result.supports[#result.supports].position
    local function px(x) return left+(right-left)*x/total end
    gc:setPen('thin','smooth');gc:drawLine(left,66,right,66)
    for i,s in ipairs(result.supports) do
        local clamp=(i==1 and continuous.left=='FIX') or (i==#result.supports and continuous.right=='FIX')
        mini_support(gc,px(s.position),66,i==1,clamp)
    end
    local top,bottom=85,h-82
    local mid=(top+bottom)/2
    local keys=mode==1 and {'Mmax','Mmin'} or (mode==2 and {'Vmax','Vmin'} or {'wodd','weven'})
    local scale=1e-10
    for _,v in ipairs(samples) do
        for _,key in ipairs(keys) do scale=math.max(scale,math.abs(v[key])) end
    end
    color(gc,115,132,148);gc:drawLine(left,mid,right,mid)
    -- M and characteristic w are positive downward; V retains its usual sign.
    local sign=mode==2 and -1 or 1
    for k,key in ipairs(keys) do
        if k==1 then color(gc,242,177,103) else color(gc,80,213,235) end
        for j=1,#samples-1 do
            local a,b=samples[j],samples[j+1]
            gc:drawLine(px(a.x),mid+sign*(bottom-top)*.45*a[key]/scale,
                px(b.x),mid+sign*(bottom-top)*.45*b[key]/scale)
        end
    end
    local v=cursor_value
    color(gc,173,198,210);gc:setPen('thin','dotted')
    gc:drawLine(px(v.x),top,px(v.x),bottom)
    color(gc,244,244,244);gc:setFont('sansserif','r',8)
    label(gc,'x='..fmt(v.x)..' m',7,h-76)
    if mode==3 then
        label(gc,'w odd='..fmt(v.wodd)..' | even='..fmt(v.weven)..' mm',7,h-61)
    else
        label(gc,'Mmax='..fmt(v.Mmax)..' | Mmin='..fmt(v.Mmin)..' kNm',7,h-61)
        if v.left then
            label(gc,'V left max/min: '..fmt(v.left.Vmax)..' / '..fmt(v.left.Vmin)..' kN',7,h-47)
            label(gc,'V right max/min: '..fmt(v.right.Vmax)..' / '..fmt(v.right.Vmin)..' kN',7,h-33)
        else label(gc,'Vmax='..fmt(v.Vmax)..' | Vmin='..fmt(v.Vmin)..' kN',7,h-47) end
    end
    color(gc,171,193,207)
    label(gc,'UP/DOWN cursor | LEFT/RIGHT mode | ENTER table',7,h-15)
end

on=on or {}
local function draw_portal_edit(gc,w,h)
    color(gc,215,225,236);gc:setFont('sansserif','r',10)
    label(gc,'PORTAL | Input',8,28)
    local count=math.max(1,math.floor((h-94)/18))
    edit_top=scroll_top(edit_index,edit_top,count)
    for i=edit_top,math.min(10,edit_top+count-1) do
        local field=portal_fields[i];local y=46+(i-edit_top)*18
        if i==edit_index then color(gc,213,232,245);gc:fillRect(6,y-1,w-12,18);color(gc,18,44,66)
        else color(gc,215,225,236) end
        fitted(gc,field[2],12,y,170,10)
        local value=portal[field[1]]
        if type(value)=='number' then value=fmt(value) end
        fitted(gc,i==edit_index and typing~=nil and typing..'_' or value,186,y,w-198,10)
    end
    color(gc,255,200,112);gc:setFont('sansserif','r',9)
    fitted(gc,err or (stale and 'Outdated | TAB: calculate' or 'Result saved'),7,h-45,w-14)
    color(gc,171,193,207)
    label(gc,'UP/DOWN field | LEFT/RIGHT base',7,h-30)
    label(gc,'ENTER apply | TAB results | ESC systems',7,h-16)
end
local function portal_arrow(gc,x0,y0,x1,y1)
    local dx,dy=x1-x0,y1-y0
    local L=math.sqrt(dx*dx+dy*dy);dx=dx/L;dy=dy/L
    local bx,by=x1-5*dx,y1-5*dy
    gc:drawLine(x0,y0,bx,by)
    gc:fillPolygon({bx-3*dy,by+3*dx,bx+3*dy,by-3*dx,x1,y1})
end
local function draw_portal_table(gc,w,h)
    color(gc,215,225,236);gc:setFont('sansserif','r',9)
    label(gc,'PORTAL | Results',7,28)
    local count=math.max(1,math.floor((h-100)/15))
    table_page=math.max(1,math.min(#samples.table-count+1,table_page))
    for i=table_page,math.min(#samples.table,table_page+count-1) do
        local row=samples.table[i];local y=46+(i-table_page)*15
        fitted(gc,row[1],8,y,166,9);fitted(gc,row[2],178,y,w-186,9)
    end
    color(gc,255,200,112);label(gc,'limits: OPEN (project / NA)',7,h-47)
    color(gc,128,222,181);fitted(gc,export_message or 'ENTER: EXPORT CAS bp_* (14)',7,h-31,w-14,9)
    color(gc,171,193,207);gc:setFont('sansserif','r',8)
    label(gc,'UP/DOWN scroll | LEFT/RIGHT mode | TAB input',7,h-15)
end
local function portal_diagram(gc,w,h)
    local titles={'M [kNm] | + tension side','V [kN] | local +y side','N [kN] | + tension','Deformed | absolute'}
    color(gc,215,225,236);gc:setFont('sansserif','r',9)
    fitted(gc,'PORTAL '..portal.base..' | '..titles[mode],7,28,w-14,9)
    fitted(gc,'q='..fmt(portal.q)..' P='..fmt(portal.P)..' H='..fmt(portal.H)..' w='..fmt(portal.w),7,43,w-14,8)
    local scale=math.min((w-100)/portal.l,(h-164)/portal.h)
    local left=(w-portal.l*scale)/2
    local bottom=h-82
    local function px(x) return left+x*scale end
    local function py(y) return bottom-y*scale end
    gc:setPen('thin','smooth')
    -- Original geometry, including both bottom->top columns.
    for i,data in ipairs(samples.members) do
        if i==portal_member then color(gc,151,184,203) else color(gc,79,105,125) end
        gc:drawLine(px(data[1].x),py(data[1].y),px(data[#data].x),py(data[#data].y))
    end
    color(gc,91,195,203)
    for _,x in ipairs{0,portal.l} do
        local xx,yy=px(x),py(0)
        if portal.base=='FIX' then
            gc:drawLine(xx-8,yy,xx+8,yy)
            for k=-1,1 do gc:drawLine(xx+k*5,yy,xx+k*5-3,yy+5) end
        else
            gc:drawLine(xx,yy,xx-7,yy+9);gc:drawLine(xx,yy,xx+7,yy+9);gc:drawLine(xx-7,yy+9,xx+7,yy+9)
        end
    end
    color(gc,246,207,97)
    local function vertical(load,x,length)
        if load~=0 then
            local a,b=py(portal.h)-length,py(portal.h)
            if load<0 then a,b=b,a end
            portal_arrow(gc,px(x),a,px(x),b)
        end
    end
    if portal.q~=0 then for k=1,3 do vertical(portal.q,portal.l*k/4,12) end end
    vertical(portal.P,portal.a,22)
    local function horizontal(load,y,length)
        if load~=0 then
            local a,b=px(0)-length,px(0)
            if load<0 then a,b=b,a end
            portal_arrow(gc,a,py(y),b,py(y))
        end
    end
    horizontal(portal.H,portal.h,24)
    if portal.w~=0 then for k=1,3 do horizontal(portal.w,portal.h*k/4,17) end end
    local key=({'M','V','N'})[mode]
    for i,data in ipairs(samples.members) do
        local function plot(v)
            if mode==4 then return px(v.x+samples.magnification*v.dx),py(v.y+samples.magnification*v.dy) end
            local amplitude=samples.scales[key]>0 and 18*v[key]/samples.scales[key] or 0
            -- M uses -local y (tension). V/N use +local y, with an explicit legend.
            local sign=mode==1 and -1 or 1
            if i==2 then return px(v.x),py(v.y)-sign*amplitude end
            return px(v.x)-sign*amplitude,py(v.y)
        end
        if mode==3 and data[1].N<0 then color(gc,80,213,235) else color(gc,242,177,103) end
        for j=1,#data-1 do
            local a,b=data[j],data[j+1]
            local ax,ay=plot(a);local bx,by=plot(b)
            -- Equal-s left/right entries draw the exact V jump, never a diagonal.
            gc:drawLine(ax,ay,bx,by)
        end
        if mode~=4 then
            for _,j in ipairs{1,#data} do
                local v=data[j];local x,y=plot(v);gc:drawLine(px(v.x),py(v.y),x,y)
            end
        end
    end
    if cursor_value then
        local x,y=portal_member==2 and portal_s or (portal_member==1 and 0 or portal.l),portal_member==2 and portal.h or portal_s
        color(gc,255,255,255);gc:fillRect(px(x)-2,py(y)-2,4,4)
        gc:setFont('sansserif','r',9)
        local side=portal_member==2 and portal.P~=0 and portal_s==portal.a and (' '..portal_side) or ''
        label(gc,'MEMBER '..portal_member..' | '..(portal_member==2 and 'BEAM' or 'COLUMN')..' | s='..fmt(portal_s)..side,7,h-64)
        fitted(gc,'N='..fmt(cursor_value.N)..' V='..fmt(cursor_value.V)..' kN  M='..fmt(cursor_value.M)..' kNm',7,h-48,w-14,9)
    end
    color(gc,171,193,207);gc:setFont('sansserif','r',8)
    fitted(gc,mode==4 and ('Magnification x'..fmt(samples.magnification)..' | beam w_rel in table') or '1/2/3 member | UP/DOWN s | ENTER table',7,h-31,w-14,8)
    label(gc,'LEFT/RIGHT mode | TAB input | ESC systems',7,h-15)
end
function on.paint(gc)
    local w=platform.window:width()
    local h=platform.window:height()
    color(gc,12,25,36);gc:fillRect(0,0,w,h)
    header(gc,w)
    if page==0 then draw_selector(gc,w,h);return end
    if params.support==6 then
        if page==1 then draw_portal_edit(gc,w,h)
        elseif calculating then
            color(gc,255,200,112);gc:setFont('sansserif','r',12);label(gc,'Calculating...',20,65)
        elseif result and samples and not stale then
            if mode==5 then draw_portal_table(gc,w,h) else portal_diagram(gc,w,h) end
        end
        return
    end
    if params.support==5 and page==2 then
        if calculating then
            color(gc,255,200,112);gc:setFont('sansserif','r',12)
            label(gc,'Calculating…',20,65)
        elseif result and samples then
            if mode==4 then draw_continuous_table(gc,w,h) else continuous_diagram(gc,w,h) end
        end
        return
    end
    if page==3 then draw_section(gc,w,h)
    elseif page==2 and result then
        if mode==4 then draw_results(gc,w,h) else diagram(gc,w,h) end
    elseif params.support==5 then draw_continuous_edit(gc,w,h)
    else draw_edit(gc,w,h) end
end
local function redraw() platform.window:invalidate() end
function on.timer()
    timer.stop()
    if not calculating or (params.support~=5 and params.support~=6) or page~=2 then return end
    local isportal=params.support==6
    local ok,sol,message
    if isportal then ok,sol,message=pcall(PortalPreset.solve,copy(portal))
    else ok,sol,message=pcall(ContinuousPreset.solve,continuous_parameters()) end
    if ok and sol then
        result=sol;summary=sol.summary
        local cached,problem=pcall(isportal and cache_portal or cache_samples)
        if not cached then ok=false;message=problem end
    end
    calculating=false
    if ok and sol then
        stale=false;err=nil;selection_before=nil
        if isportal then portal_confirmed={parameters=copy(portal),result=result,samples=samples} end
    else
        if not ok and not message then message=sol end
        if isportal and not selection_before and portal_confirmed then
            portal=copy(portal_confirmed.parameters);result=portal_confirmed.result;summary=result.summary
            samples=portal_confirmed.samples;stale=false;cache_cursor()
            page=1;err=message or 'calculation failed'
        else
            samples=nil;cursor_value=nil;characteristic=nil;result=nil;summary=nil
            rollback_selection(message or 'calculation failed')
        end
    end
    redraw()
end
local function apply_edit(key,v)
    if key=='manualEI' or key=='b' or key=='h' then
        local old=section[key]
        section[key]=v
        local info,msg=sec_info()
        if not info then
            section[key]=old
            if params.support~=5 then result=nil;summary=nil end
            export_message=nil;err=msg;return
        end
        recalc()
        return
    end
    if key=='EI' and section.material~=1 then
        err='EI from section; use TAB';return
    end
    local old=params[key]
    local olda=params.a
    if key=='EI' then apply_edit('manualEI',v)
    else
        params[key]=v
        -- If there is no point load, its inactive position does not prevent reducing L.
        if key=='L' and params.P==0 and v>0 and params.a>v then params.a=v/2 end
        if not recalc() then params[key]=old;params.a=olda end
    end
end
local function apply_continuous(key,v)
    local candidate=copy(continuous)
    if type(key)=='number' then candidate.spans[key]=v else candidate[key]=v end
    local p=copy(candidate)
    p.EI=params.EI;p.limit=settings.limit
    p.g=p.g+(settings.self_weight and q_sw or 0)
    local valid,message=ContinuousPreset.model(p,'G')
    if not valid then err=message;return end
    continuous=candidate;dirty()
end
local function apply_portal(key,value)
    local candidate=copy(portal);candidate[key]=value
    if key=='l' and candidate.P==0 and finite(value) and value>0 and candidate.a>value then candidate.a=value/2 end
    local valid,message=PortalPreset.model(candidate)
    if not valid then err=message;export_message=nil;return end
    if candidate[key]==portal[key] and candidate.a==portal.a then err=nil;return end
    portal=candidate;portal_s=math.min(portal_s,portal_member==2 and portal.l or portal.h)
    dirty_portal()
end
local function commit()
    if typing==nil then return end
    local v=tonumber(typing)
    -- Invalid text never changed the model; retain its last valid solution.
    if v==nil then export_message=nil;err='invalid number'
    elseif page==1 and params.support==6 then apply_portal(portal_fields[edit_index][1],v)
    elseif page==1 and params.support==5 then
        local key=continuous_rows()[edit_index].key
        if type(key)=='number' or key=='g' or key=='q' or key=='gG_sup' or key=='gG_inf' or key=='gQ' then
            apply_continuous(key,v)
        end
    elseif page==1 then apply_edit(names[edit_index],v)
    elseif page==3 then
        local row=active_section_index()[sec_index]
        if row and row.editable and row.key~='material' and row.key~='profile'
           and row.key~='self_weight' then
            apply_edit(row.key,v)
        end
    end
    typing=nil
end
local function step_selection(d)
    if page==1 and params.support==6 then
        if edit_index==1 then apply_portal('base',portal.base=='PIN' and 'FIX' or 'PIN') end
    elseif page==1 and params.support==5 then
        local key=continuous_rows()[edit_index].key
        if key=='n' then
            local n=math.max(2,math.min(ContinuousPreset.MAX_SPANS,#continuous.spans+d))
            if n~=#continuous.spans then
                local spans={}
                for i=1,n do spans[i]=continuous.spans[i] or continuous.spans[#continuous.spans] end
                continuous.spans=spans;dirty()
            end
        elseif key=='left' or key=='right' then
            apply_continuous(key,continuous[key]=='PIN' and 'FIX' or 'PIN')
        end
    elseif page==1 and edit_index==1 then
        params.support=(params.support-1+d+4)%4+1
        recalc()
    elseif page==3 then
        local row=active_section_index()[sec_index]
        if row.key=='material' then
            section.material=(section.material-1+d+#SectionDB.materials)%#SectionDB.materials+1
            sec_index=1;recalc()
        elseif row.key=='profile' then
            section.profile=(section.profile-1+d+#SectionDB.profiles)%#SectionDB.profiles+1
            recalc()
        elseif row.key=='self_weight' then
            local info=sec_info()
            if info and info.q_sw then settings.self_weight=not settings.self_weight end
            recalc()
        elseif row.key=='limit' then
            settings.limit=settings.limit==250 and 300 or 250
            recalc()
        end
    end
end
local function dismiss_restore_notice()
    if restore_notice then restore_notice=nil;redraw() end
end
function on.tabKey()
    dismiss_restore_notice()
    if page==0 then return end
    local was_editing=typing~=nil
    commit()
    if params.support==6 then
        if not was_editing or not err then
            if page==1 then err=nil;show_results() else page=1 end
        elseif page==2 then page=1 end
        if calculating and page~=2 then timer.stop();calculating=false end
        redraw();return
    end
    if result or params.support==5 then
        if page==1 then show_results()
        elseif page==2 then page=3
        elseif page==3 then page=1 end
    end
    if calculating and page~=2 then timer.stop();calculating=false end
    redraw()
end
function on.enterKey()
    dismiss_restore_notice()
    if page==0 then open_selected_system();redraw();return end
    if page==1 then
        if params.support==6 then commit()
        elseif params.support==5 then
            if typing~=nil then commit() else step_selection(1) end
        elseif edit_index==1 then step_selection(1) else commit() end
    elseif page==2 then
        if not calculating then
            local tablemode=params.support==6 and 5 or 4
            if mode==tablemode then export_cas() else mode=tablemode end
        end
    elseif page==3 then
        local row=active_section_index()[sec_index]
        if row.key=='material' or row.key=='profile' or row.key=='self_weight' or row.key=='limit' then step_selection(1)
        else commit() end
    end
    redraw()
end
function on.charIn(ch)
    dismiss_restore_notice()
    if page==0 then return end
    if params.support==6 and page==2 then
        local member=tonumber(ch)
        if not calculating and mode~=5 and member and member%1==0 and member>=1 and member<=3 and member~=portal_member then
            portal_member=member;cache_cursor();redraw()
        end
        return
    end
    local can=false
    if page==1 and params.support==6 then can=edit_index~=1
    elseif page==1 and params.support==5 then
        local key=continuous_rows()[edit_index].key
        can=key~='n' and key~='left' and key~='right'
    elseif page==1 then can=edit_index~=1 and (names[edit_index]~='EI' or section.material==1)
    elseif page==3 then
        local row=active_section_index()[sec_index]
        can=row.editable and row.key~='material' and row.key~='profile' and row.key~='self_weight' and row.key~='limit'
    end
    if not can then return end
    if ch=='−' then ch='-' end -- TI handheld minus key can send U+2212
    if string.match(ch,'^[0-9%.%-]$') then
        typing=(typing or '')..ch
        redraw()
    end
end
function on.backspaceKey()
    dismiss_restore_notice()
    if page==0 then return end
    if typing and #typing>0 then typing=string.sub(typing,1,-2) end
    redraw()
end
function on.escapeKey()
    dismiss_restore_notice()
    if page==0 then return end
    if typing~=nil then typing=nil;err=nil
    else
        if calculating then timer.stop();calculating=false end
        if result~=nil then err=nil end
        page=0;sel_index=params.support;selector_error=nil
    end
    redraw()
end
local function move_field(d)
    if page==1 then
        local count=params.support==6 and 10 or (params.support==5 and #continuous_rows() or #names)
        edit_index=math.max(1,math.min(count,edit_index+d))
    elseif page==3 then
        local rows=section_rows()
        local i=sec_index+d
        while i>=1 and i<=#rows do
            if rows[i].editable then sec_index=i;break end
            i=i+d
        end
    end
end
local function move_continuous_cursor(d)
    if not result or not samples then return end
    local total=result.supports[#result.supports].position
    local old=cursor*total
    local x=math.max(0,math.min(total,old+d*.025*total))
    -- Include every support in the cursor path, also with unequal span lengths.
    for _,s in ipairs(result.supports) do
        if d>0 and s.position>old+1e-9*total and s.position<x then x=s.position end
        if d<0 and s.position<old-1e-9*total and s.position>x then x=s.position end
    end
    if x~=old then cursor=x/total;cache_cursor() end
end
local function move_portal_cursor(direction)
    if calculating or not samples then return end
    if mode==5 then
        table_page=math.max(1,math.min(#samples.table,table_page-direction));return
    end
    local data=samples.members[portal_member]
    local index=direction>0 and #data or 1
    if direction>0 then
        for i,v in ipairs(data) do
            if v.s>portal_s or (v.s==portal_s and v.side=='right' and portal_side=='left') then index=i;break end
        end
    else
        for i=#data,1,-1 do
            local v=data[i]
            if v.s<portal_s or (v.s==portal_s and v.side=='left' and portal_side=='right') then index=i;break end
        end
    end
    local v=data[index]
    if v.s~=portal_s or v.side~=portal_side then portal_s=v.s;portal_side=v.side;cache_cursor() end
end
function on.arrowUp()
    dismiss_restore_notice()
    if page==0 then
        if sel_index>3 then sel_index=sel_index-3 end
        redraw();return
    end
    if page==2 and params.support==6 then move_portal_cursor(1);redraw();return end
    if page==2 and params.support==5 then
        if not calculating then
            if mode==4 then table_page=1 else move_continuous_cursor(1) end
        end
        redraw();return
    end
    if page==2 and mode==4 then
        settings.limit=settings.limit==250 and 300 or 250
        if result then
            result.deflection_check=BeamPreset.deflection_check(result,settings.limit,lref_factor())
        end
    elseif page==2 then cursor=math.min(1,cursor+0.025)
    else commit();move_field(-1) end
    redraw()
end
function on.arrowDown()
    dismiss_restore_notice()
    if page==0 then
        if sel_index<=3 then sel_index=sel_index+3 end
        redraw();return
    end
    if page==2 and params.support==6 then move_portal_cursor(-1);redraw();return end
    if page==2 and params.support==5 then
        if not calculating then
            if mode==4 then table_page=2 else move_continuous_cursor(-1) end
        end
        redraw();return
    end
    if page==2 and mode==4 then
        settings.limit=settings.limit==250 and 300 or 250
        if result then
            result.deflection_check=BeamPreset.deflection_check(result,settings.limit,lref_factor())
        end
    elseif page==2 then cursor=math.max(0,cursor-0.025)
    else commit();move_field(1) end
    redraw()
end
function on.arrowLeft()
    dismiss_restore_notice()
    if page==0 then
        if (sel_index-1)%3>0 then sel_index=sel_index-1 end
        redraw();return
    end
    if page==2 and params.support==6 then mode=(mode+3)%5+1
    elseif page==2 then mode=(mode+2)%4+1
    else commit();step_selection(-1) end
    redraw()
end
function on.arrowRight()
    dismiss_restore_notice()
    if page==0 then
        if (sel_index-1)%3<2 then sel_index=sel_index+1 end
        redraw();return
    end
    if page==2 and params.support==6 then mode=mode%5+1
    elseif page==2 then mode=mode%4+1
    else commit();step_selection(1) end
    redraw()
end
-- Saved inside the .tns document when the user saves it (TI Lua API on.save/restore).
function on.save()
    return {format='0.6.0',params=copy(params),section=copy(section),portal=copy(portal),
        continuous=copy(continuous),page=page,mode=mode,cursor=cursor,
        portal_member=portal_member,portal_s=portal_s,portal_side=portal_side,
        settings=copy(settings)}
end
local function valid_document(data)
    if type(data)~='table' or data.format~='0.6.0' then return false end
    local p,s,c,t=data.params,data.section,data.continuous,data.settings
    if type(p)~='table' or type(s)~='table' or type(c)~='table' or type(t)~='table' then return false end
    local function integer(v,lo,hi) return finite(v) and v%1==0 and v>=lo and v<=hi end
    if not PortalPreset.model(data.portal) or not integer(data.portal_member,1,3)
       or not finite(data.portal_s) or data.portal_s<0
       or data.portal_s>(data.portal_member==2 and data.portal.l or data.portal.h)
       or (data.portal_side~='left' and data.portal_side~='right') then return false end
    if not integer(data.page,0,3) or not integer(data.mode,1,p.support==6 and 5 or 4)
       or not finite(data.cursor) or data.cursor<0 or data.cursor>1 then return false end
    if p.support==6 and data.page==3 then return false end
    if not integer(p.support,1,6) or not finite(p.L) or p.L<=0
       or not finite(p.EI) or p.EI<=0 or not finite(p.q) or not finite(p.P)
       or not finite(p.a) or p.a<0 or p.a>p.L then return false end
    if not integer(s.material,1,#SectionDB.materials)
       or not integer(s.profile,1,#SectionDB.profiles) then return false end
    for _,key in ipairs{'b','h','manualEI'} do
        if not finite(s[key]) or s[key]<=0 then return false end
    end
    local info=SectionDB.compute(s)
    if not info or not finite(info.EI) or info.EI<=0 then return false end
    if type(t.self_weight)~='boolean' or (t.limit~=250 and t.limit~=300) then return false end
    if type(c.spans)~='table' or not integer(#c.spans,2,ContinuousPreset.MAX_SPANS) then return false end
    for key in pairs(c.spans) do if not integer(key,1,#c.spans) then return false end end
    for i=1,#c.spans do if not finite(c.spans[i]) or c.spans[i]<=0 then return false end end
    if (c.left~='PIN' and c.left~='FIX') or (c.right~='PIN' and c.right~='FIX') then return false end
    if not finite(c.g) or not finite(c.q) then return false end
    for _,key in ipairs{'gG_sup','gG_inf','gQ'} do
        if not finite(c[key]) or c[key]<=0 then return false end
    end
    return true
end
function on.restore(data)
    if calculating then timer.stop() end
    local valid=valid_document(data)
    params=copy(default_params);section=copy(default_section);continuous=copy(default_continuous)
    portal=copy(default_portal);portal_member=2;portal_s=3;portal_side='left';portal_confirmed=nil
    settings={self_weight=false,limit=250}
    page=0;mode=1;cursor=.5;table_page=1;edit_index=1;sec_index=1;edit_top=1;sec_top=1
    typing=nil;selector_error=nil;selection_before=nil;restore_notice=nil
    dirty()
    if valid then
        params=copy(data.params);section=copy(data.section);continuous=copy(data.continuous)
        portal=copy(data.portal);portal_member=data.portal_member;portal_s=data.portal_s;portal_side=data.portal_side
        settings=copy(data.settings)
    else
        restore_notice='Invalid document or version: defaults restored'
    end
    recalc()
    if valid then
        page=data.page;mode=data.mode;cursor=data.cursor
        -- Results reopen at input; no continuous solve until the user enters results.
        if (params.support==5 or params.support==6) and page==2 then page=1 end
    end
    sel_index=params.support
    redraw()
end
